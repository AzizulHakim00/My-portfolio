package com.example.realmadrid.Model;

/**
 * Central database configuration.
 *
 * Defaults are friendly for XAMPP/MySQL on localhost. Override them with
 * environment variables when needed:
 * REALMADRID_DB_URL, REALMADRID_DB_USER, REALMADRID_DB_PASSWORD.
 */
public final class DatabaseConfig {
    private static final String DEFAULT_URL = "jdbc:mysql://localhost:3306/realmadrid?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String DEFAULT_USER = "root";
    private static final String DEFAULT_PASSWORD = "";

    private DatabaseConfig() {
    }

    public static String url() {
        return envOrDefault("REALMADRID_DB_URL", DEFAULT_URL);
    }

    public static String username() {
        return envOrDefault("REALMADRID_DB_USER", DEFAULT_USER);
    }

    public static String password() {
        String value = System.getenv("REALMADRID_DB_PASSWORD");
        return value == null ? DEFAULT_PASSWORD : value;
    }

    private static String envOrDefault(String name, String defaultValue) {
        String value = System.getenv(name);
        return value == null || value.isBlank() ? defaultValue : value;
    }
}
