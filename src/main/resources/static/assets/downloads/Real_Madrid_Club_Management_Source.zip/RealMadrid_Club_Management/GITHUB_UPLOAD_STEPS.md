# GitHub Upload Steps

## 1. Create an empty repository on GitHub

Do not select "Add a README", "Add .gitignore", or "Choose a license" during repository creation, because this project already includes README and .gitignore files.

Recommended repository name:

```text
real-madrid-management-system
```

## 2. Open terminal inside the project root

The project root is the folder that contains:

```text
pom.xml
src/
database/
README.md
.gitignore
```

## 3. Push the project

Replace `YOUR_USERNAME` and `YOUR_REPOSITORY_NAME` with your GitHub username and repository name.

```bash
git init
git add .
git commit -m "Initial commit: Real Madrid management system"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME.git
git push -u origin main
```

## 4. What not to upload

Do not upload the original full ZIP contents. Keep this cleaned project only.

Removed/unneeded items include:

```text
CalendarFX-11.12.7/
demo/
football-transfer-market/
formation/
Labfinal/
practiceForQuiz/
Soccer-Club-Management-System-main/
target/
.idea/
*.iml
*.jar
*.zip
*.db
*.mov
random files outside src/
```
