# Real Madrid Management System

A JavaFX desktop application with MySQL database support for managing Real Madrid-style club data, including login, dashboard views, match information, players, transfer window data, training sessions, and player performance/status records.

## Tech stack

- Java 17+
- JavaFX 21
- Maven
- MySQL / MariaDB / XAMPP MySQL

## Repository structure

```text
.
├── src/main/java/              # Java source code
├── src/main/resources/         # FXML, CSS, and image resources
├── database/real.sql           # Database schema and sample data
├── pom.xml                     # Maven dependencies and plugins
├── mvnw / mvnw.cmd             # Maven Wrapper
├── team1_formation.txt         # Formation data file used by the app
├── team2_formation.txt         # Formation data file used by the app
└── .gitignore                  # Files that should not be committed
```

## Requirements

Install these before running the project:

1. JDK 17 or JDK 21
2. MySQL Server, MariaDB, or XAMPP MySQL
3. Internet connection for the first Maven run, so dependencies can be downloaded

Avoid JDK 23/24 for this project unless you know your JavaFX/Maven setup is compatible. JDK 17 or 21 is recommended.

## Database setup

Start MySQL first, then import the database.

For XAMPP / root with no password:

```bash
mysql -u root < database/real.sql
```

For MySQL root with password:

```bash
mysql -u root -p < database/real.sql
```

The SQL file creates and uses this database:

```sql
realmadrid
```

Default database connection used by the app:

```text
URL: jdbc:mysql://localhost:3306/realmadrid?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
User: root
Password: empty
```

To use a different database user/password, set environment variables before running.

Windows PowerShell:

```powershell
$env:REALMADRID_DB_USER="root"
$env:REALMADRID_DB_PASSWORD="your_password"
$env:REALMADRID_DB_URL="jdbc:mysql://localhost:3306/realmadrid?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC"
```

macOS/Linux:

```bash
export REALMADRID_DB_USER=root
export REALMADRID_DB_PASSWORD=your_password
export REALMADRID_DB_URL=jdbc:mysql://localhost:3306/realmadrid?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
```

## Run the project

### Windows PowerShell

```powershell
.\mvnw.cmd clean javafx:run
```

### macOS/Linux

```bash
chmod +x mvnw
./mvnw clean javafx:run
```

## IntelliJ IDEA setup

Open the project using the root `pom.xml` file:

```text
File -> Open -> select pom.xml -> Open as Project
```

Recommended run configuration:

```text
Run -> Edit Configurations -> + -> Maven
Working directory: project root folder
Command line: clean javafx:run
```

If you run it as an Application configuration, use this main class:

```text
com.example.realmadrid.Launcher
```

Do not run `com.example.realmadrid.App` directly from IntelliJ, because JavaFX apps often need Maven/JavaFX launch configuration.

## Login credentials

Coach login:

```text
username: xabi
password: 1234
```

Admin login:

```text
username: admin
password: 1234
```

## GitHub upload

After creating an empty GitHub repository, run these commands from the project root:

```bash
git init
git add .
git commit -m "Initial commit: Real Madrid management system"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME.git
git push -u origin main
```

Recommended repository name:

```text
real-madrid-management-system
```

## Notes

This repository has been cleaned for GitHub upload. Unrelated projects, generated build output, local IDE settings, local ZIP/JAR files, and hardcoded local machine paths were removed. Maven dependencies are declared in `pom.xml`, so dependency JAR files should not be committed manually.
