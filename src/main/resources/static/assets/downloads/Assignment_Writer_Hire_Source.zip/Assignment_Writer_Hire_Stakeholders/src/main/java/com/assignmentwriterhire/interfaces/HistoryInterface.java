package com.assignmentwriterhire.interfaces;

import com.assignmentwriterhire.model.HistoryRecord;

import java.util.List;

public interface HistoryInterface {

    void addHistory(
            int userId,
            String actor,
            String action,
            String details
    ) throws Exception;

    List<HistoryRecord> getHistoryByUser(int userId) throws Exception;

    List<HistoryRecord> getAllHistory() throws Exception;
}
