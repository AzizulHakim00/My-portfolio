#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if [ -z "$JAVA_HOME" ]; then
  JAVA_HOME=$(java -XshowSettings:properties -version 2>&1 | awk -F'= ' '/java.home =/ {print $2; exit}')
  export JAVA_HOME
fi
./mvnw -U clean javafx:run
