package com.assignmentwriterhire.controller;

import com.assignmentwriterhire.Main;
import com.assignmentwriterhire.services.AuthService;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class RegisterController {

    @FXML
    private TextField fullNameField;

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private PasswordField confirmPasswordField;

    @FXML
    private Label messageLabel;

    private final AuthService authService = new AuthService();

    @FXML
    private void createAccount() {
        String fullName = fullNameField.getText().trim();
        String username = usernameField.getText().trim();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();

        if (fullName.isEmpty()
                || username.isEmpty()
                || password.isEmpty()
                || confirmPassword.isEmpty()) {
            messageLabel.setText("Complete all fields.");
            return;
        }

        if (username.length() < 4) {
            messageLabel.setText("Username must have at least 4 characters.");
            return;
        }

        if (password.length() < 4) {
            messageLabel.setText("Password must have at least 4 characters.");
            return;
        }

        if (!password.equals(confirmPassword)) {
            messageLabel.setText("The passwords do not match.");
            return;
        }

        try {
            boolean created = authService.register(
                    fullName,
                    username,
                    password
            );

            if (!created) {
                messageLabel.setText("That username is already being used.");
                return;
            }

            ControllerHelper.showInfo(
                    "Account created",
                    "Your user account is ready. You can now log in."
            );
            backToLogin();
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("The account could not be created.");
        }
    }

    @FXML
    private void backToLogin() {
        try {
            Main.changeScene("login-view.fxml");
        } catch (Exception exception) {
            exception.printStackTrace();
            ControllerHelper.showError(exception.getMessage());
        }
    }
}
