package com.assignmentwriterhire.interfaces;

import com.assignmentwriterhire.model.AssignmentRequest;

import java.util.List;

public interface AssignmentInterface {

    void createRequest(AssignmentRequest request) throws Exception;

    List<AssignmentRequest> getRequestsByUser(int userId) throws Exception;

    List<AssignmentRequest> getOpenRequestsByUser(int userId) throws Exception;

    List<AssignmentRequest> getAllRequests() throws Exception;

    void updateStatus(int requestId, String status) throws Exception;

    void deleteRequest(int requestId) throws Exception;

    int countOpenRequestsByUser(int userId) throws Exception;

    int countAllRequests() throws Exception;
}
