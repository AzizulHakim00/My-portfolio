package com.assignmentwriterhire.controller;

import com.assignmentwriterhire.model.HistoryRecord;
import com.assignmentwriterhire.model.User;
import com.assignmentwriterhire.services.HistoryService;
import com.assignmentwriterhire.session.Session;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class UserHistoryController extends UserNavigationController {

    @FXML
    private TableView<HistoryRecord> historyTable;

    @FXML
    private TableColumn<HistoryRecord, String> actionColumn;

    @FXML
    private TableColumn<HistoryRecord, String> detailsColumn;

    @FXML
    private TableColumn<HistoryRecord, String> dateColumn;

    @FXML
    private Label messageLabel;

    private final HistoryService historyService = new HistoryService();

    @FXML
    private void initialize() {
        actionColumn.setCellValueFactory(
                new PropertyValueFactory<>("action")
        );
        detailsColumn.setCellValueFactory(
                new PropertyValueFactory<>("details")
        );
        dateColumn.setCellValueFactory(
                new PropertyValueFactory<>("actionDate")
        );
        loadHistory();
    }

    @FXML
    private void loadHistory() {
        User user = Session.getCurrentUser();
        if (user == null) {
            changeScene("login-view.fxml");
            return;
        }

        try {
            historyTable.setItems(FXCollections.observableArrayList(
                    historyService.getHistoryByUser(user.getId())
            ));
            messageLabel.setText("");
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("History could not be loaded.");
        }
    }
}
