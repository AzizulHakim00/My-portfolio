package com.assignmentwriterhire;

import com.assignmentwriterhire.singleton.DatabaseConnection;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

import java.net.URL;

public class Main {

    private static Stage mainStage;

    public static void main(String[] args) {
        Application.launch(AssignmentWriterApplication.class, args);
    }

    public static class AssignmentWriterApplication extends Application {

        @Override
        public void start(Stage stage) {
            mainStage = stage;
            mainStage.setTitle("Assignment Writer Hire");
            mainStage.setResizable(false);

            try {
                DatabaseConnection.getInstance().setupDatabase();
                changeScene("login-view.fxml");
            } catch (Exception exception) {
                exception.printStackTrace();
                showStartupError(exception);
            }
        }
    }

    public static void changeScene(String fxmlFile) throws Exception {
        URL fxmlUrl = Main.class.getResource(
                "/com/assignmentwriterhire/" + fxmlFile
        );

        if (fxmlUrl == null) {
            throw new IllegalArgumentException(
                    "FXML file was not found: " + fxmlFile
            );
        }

        FXMLLoader loader = new FXMLLoader(fxmlUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root, 1100, 700);

        URL cssUrl = Main.class.getResource(
                "/com/assignmentwriterhire/styles.css"
        );

        if (cssUrl != null) {
            scene.getStylesheets().add(cssUrl.toExternalForm());
        }

        mainStage.setScene(scene);
        mainStage.centerOnScreen();
        mainStage.show();
    }

    public static Stage getMainStage() {
        return mainStage;
    }

    private static void showStartupError(Exception exception) {
        Throwable root = exception;
        while (root.getCause() != null) {
            root = root.getCause();
        }

        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("MySQL connection problem");
        alert.setHeaderText("The application could not start.");
        alert.setContentText(
                "Start MySQL Server and check these settings:\n\n"
                        + "Host: localhost:3306\n"
                        + "Username: root\n"
                        + "Password: password\n"
                        + "Database: assignment_writer_hire_db\n\n"
                        + "Error: " + root.getMessage()
        );
        alert.showAndWait();
    }
}
