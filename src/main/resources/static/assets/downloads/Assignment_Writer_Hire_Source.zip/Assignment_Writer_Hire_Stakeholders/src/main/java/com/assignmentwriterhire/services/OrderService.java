package com.assignmentwriterhire.services;

import com.assignmentwriterhire.interfaces.OrderInterface;
import com.assignmentwriterhire.model.Order;
import com.assignmentwriterhire.singleton.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class OrderService implements OrderInterface {

    private static final DateTimeFormatter FORMATTER =
            DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a");

    @Override
    public void createOrder(
            int userId,
            int assignmentId,
            int writerId,
            double price
    ) throws Exception {
        String insertOrder = """
                INSERT INTO orders(
                    user_id, assignment_id, writer_id,
                    price, status, progress, created_at
                ) VALUES (?, ?, ?, ?, 'Pending', 0, ?)
                """;

        String updateRequest = """
                UPDATE assignment_requests
                SET status = 'Assigned'
                WHERE id = ? AND user_id = ? AND status = 'Open'
                """;

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection()) {
            connection.setAutoCommit(false);

            try (PreparedStatement orderStatement =
                         connection.prepareStatement(insertOrder);
                 PreparedStatement requestStatement =
                         connection.prepareStatement(updateRequest)) {

                requestStatement.setInt(1, assignmentId);
                requestStatement.setInt(2, userId);

                if (requestStatement.executeUpdate() == 0) {
                    throw new IllegalStateException(
                            "The selected request is no longer open."
                    );
                }

                orderStatement.setInt(1, userId);
                orderStatement.setInt(2, assignmentId);
                orderStatement.setInt(3, writerId);
                orderStatement.setDouble(4, price);
                orderStatement.setString(
                        5,
                        LocalDateTime.now().format(FORMATTER)
                );
                orderStatement.executeUpdate();
                connection.commit();
            } catch (Exception exception) {
                connection.rollback();
                throw exception;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    @Override
    public List<Order> getOrdersByUser(int userId) throws Exception {
        String sql = baseSelect()
                + " WHERE o.user_id = ? ORDER BY o.id DESC";

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, userId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return readOrders(resultSet);
            }
        }
    }

    @Override
    public List<Order> getAllOrders() throws Exception {
        String sql = baseSelect() + " ORDER BY o.id DESC";

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            return readOrders(resultSet);
        }
    }

    @Override
    public void updateOrder(
            int orderId,
            String status,
            int progress
    ) throws Exception {
        String updateOrder =
                "UPDATE orders SET status = ?, progress = ? WHERE id = ?";

        String requestStatus;
        if ("Completed".equals(status)) {
            requestStatus = "Completed";
        } else if ("Cancelled".equals(status)) {
            requestStatus = "Open";
        } else if ("Submitted".equals(status)) {
            requestStatus = "In Review";
        } else {
            requestStatus = "Assigned";
        }

        String updateRequest = """
                UPDATE assignment_requests
                SET status = ?
                WHERE id = (
                    SELECT assignment_id FROM orders WHERE id = ?
                )
                """;

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection()) {
            connection.setAutoCommit(false);

            try (PreparedStatement orderStatement =
                         connection.prepareStatement(updateOrder);
                 PreparedStatement requestStatement =
                         connection.prepareStatement(updateRequest)) {

                orderStatement.setString(1, status);
                orderStatement.setInt(2, progress);
                orderStatement.setInt(3, orderId);
                orderStatement.executeUpdate();

                requestStatement.setString(1, requestStatus);
                requestStatement.setInt(2, orderId);
                requestStatement.executeUpdate();

                connection.commit();
            } catch (Exception exception) {
                connection.rollback();
                throw exception;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    @Override
    public void cancelOrder(int orderId, int assignmentId) throws Exception {
        String cancelOrder = """
                UPDATE orders
                SET status = 'Cancelled', progress = 0
                WHERE id = ? AND status NOT IN ('Completed', 'Cancelled')
                """;

        String reopenRequest = """
                UPDATE assignment_requests
                SET status = 'Open'
                WHERE id = ?
                """;

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection()) {
            connection.setAutoCommit(false);

            try (PreparedStatement orderStatement =
                         connection.prepareStatement(cancelOrder);
                 PreparedStatement requestStatement =
                         connection.prepareStatement(reopenRequest)) {

                orderStatement.setInt(1, orderId);
                if (orderStatement.executeUpdate() == 0) {
                    throw new IllegalStateException(
                            "This order cannot be cancelled."
                    );
                }

                requestStatement.setInt(1, assignmentId);
                requestStatement.executeUpdate();
                connection.commit();
            } catch (Exception exception) {
                connection.rollback();
                throw exception;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    @Override
    public int countActiveOrdersByUser(int userId) throws Exception {
        String sql = """
                SELECT COUNT(*) FROM orders
                WHERE user_id = ?
                  AND status NOT IN ('Completed', 'Cancelled')
                """;

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, userId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? resultSet.getInt(1) : 0;
            }
        }
    }

    @Override
    public int countAllOrders() throws Exception {
        String sql = "SELECT COUNT(*) FROM orders";

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            return resultSet.next() ? resultSet.getInt(1) : 0;
        }
    }

    private String baseSelect() {
        return """
                SELECT o.id, o.user_id, u.full_name AS user_name,
                       o.assignment_id, r.title AS assignment_title,
                       o.writer_id, w.name AS writer_name,
                       o.price, o.status, o.progress, o.created_at
                FROM orders o
                JOIN users u ON o.user_id = u.id
                JOIN assignment_requests r ON o.assignment_id = r.id
                JOIN writers w ON o.writer_id = w.id
                """;
    }

    private List<Order> readOrders(ResultSet resultSet) throws Exception {
        List<Order> orders = new ArrayList<>();

        while (resultSet.next()) {
            orders.add(new Order(
                    resultSet.getInt("id"),
                    resultSet.getInt("user_id"),
                    resultSet.getString("user_name"),
                    resultSet.getInt("assignment_id"),
                    resultSet.getString("assignment_title"),
                    resultSet.getInt("writer_id"),
                    resultSet.getString("writer_name"),
                    resultSet.getDouble("price"),
                    resultSet.getString("status"),
                    resultSet.getInt("progress"),
                    resultSet.getString("created_at")
            ));
        }
        return orders;
    }
}
