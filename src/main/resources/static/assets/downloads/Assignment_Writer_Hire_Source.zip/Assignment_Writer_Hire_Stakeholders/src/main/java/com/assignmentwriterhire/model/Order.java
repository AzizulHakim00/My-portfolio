package com.assignmentwriterhire.model;

public class Order {

    private int id;
    private int userId;
    private String userName;
    private int assignmentId;
    private String assignmentTitle;
    private int writerId;
    private String writerName;
    private double price;
    private String status;
    private int progress;
    private String createdAt;

    public Order() {
    }

    public Order(
            int id,
            int userId,
            String userName,
            int assignmentId,
            String assignmentTitle,
            int writerId,
            String writerName,
            double price,
            String status,
            int progress,
            String createdAt
    ) {
        this.id = id;
        this.userId = userId;
        this.userName = userName;
        this.assignmentId = assignmentId;
        this.assignmentTitle = assignmentTitle;
        this.writerId = writerId;
        this.writerName = writerName;
        this.price = price;
        this.status = status;
        this.progress = progress;
        this.createdAt = createdAt;
    }

    public int getId() {
        return id;
    }

    public int getUserId() {
        return userId;
    }

    public String getUserName() {
        return userName;
    }

    public int getAssignmentId() {
        return assignmentId;
    }

    public String getAssignmentTitle() {
        return assignmentTitle;
    }

    public int getWriterId() {
        return writerId;
    }

    public String getWriterName() {
        return writerName;
    }

    public double getPrice() {
        return price;
    }

    public String getStatus() {
        return status;
    }

    public int getProgress() {
        return progress;
    }

    public String getProgressText() {
        return progress + "%";
    }

    public String getCreatedAt() {
        return createdAt;
    }
}
