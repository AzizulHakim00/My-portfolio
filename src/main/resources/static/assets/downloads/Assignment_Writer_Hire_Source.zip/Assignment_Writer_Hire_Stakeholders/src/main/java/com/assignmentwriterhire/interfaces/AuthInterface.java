package com.assignmentwriterhire.interfaces;

import com.assignmentwriterhire.model.User;

public interface AuthInterface {

    User login(String username, String password) throws Exception;

    boolean register(
            String fullName,
            String username,
            String password
    ) throws Exception;
}
