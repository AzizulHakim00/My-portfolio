package com.assignmentwriterhire.model;

public class Writer {

    private int id;
    private String name;
    private String specialty;
    private int experience;
    private double rating;
    private double rate;
    private boolean available;

    public Writer() {
    }

    public Writer(
            int id,
            String name,
            String specialty,
            int experience,
            double rating,
            double rate,
            boolean available
    ) {
        this.id = id;
        this.name = name;
        this.specialty = specialty;
        this.experience = experience;
        this.rating = rating;
        this.rate = rate;
        this.available = available;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public boolean isAvailable() {
        return available;
    }

    public String getAvailabilityText() {
        return available ? "Available" : "Unavailable";
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    @Override
    public String toString() {
        return name + " - " + specialty;
    }
}
