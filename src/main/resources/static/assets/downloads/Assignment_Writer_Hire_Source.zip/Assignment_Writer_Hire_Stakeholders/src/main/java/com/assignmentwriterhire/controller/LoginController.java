package com.assignmentwriterhire.controller;

import com.assignmentwriterhire.Main;
import com.assignmentwriterhire.model.User;
import com.assignmentwriterhire.services.AuthService;
import com.assignmentwriterhire.services.HistoryService;
import com.assignmentwriterhire.session.Session;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label messageLabel;

    private final AuthService authService = new AuthService();
    private final HistoryService historyService = new HistoryService();

    @FXML
    private void loginButtonClicked() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            messageLabel.setText("Enter your username and password.");
            return;
        }

        try {
            User user = authService.login(username, password);

            if (user == null) {
                messageLabel.setText("The username or password is incorrect.");
                return;
            }

            if (!"Active".equalsIgnoreCase(user.getStatus())) {
                messageLabel.setText("This account is blocked. Contact the admin.");
                return;
            }

            Session.setCurrentUser(user);
            historyService.addHistory(
                    user.getId(),
                    user.getFullName(),
                    "Login",
                    user.getRole() + " signed in"
            );

            if ("Admin".equalsIgnoreCase(user.getRole())) {
                Main.changeScene("admin-dashboard-view.fxml");
            } else {
                Main.changeScene("user-dashboard-view.fxml");
            }
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("Could not connect to the database.");
        }
    }

    @FXML
    private void openRegistration() {
        try {
            Main.changeScene("register-view.fxml");
        } catch (Exception exception) {
            exception.printStackTrace();
            ControllerHelper.showError(exception.getMessage());
        }
    }
}
