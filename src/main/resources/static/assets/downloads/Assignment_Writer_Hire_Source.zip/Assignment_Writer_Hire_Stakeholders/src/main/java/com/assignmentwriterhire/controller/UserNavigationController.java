package com.assignmentwriterhire.controller;

import com.assignmentwriterhire.Main;
import com.assignmentwriterhire.session.Session;
import javafx.fxml.FXML;

public abstract class UserNavigationController {

    @FXML
    public void goToUserDashboard() {
        changeScene("user-dashboard-view.fxml");
    }

    @FXML
    public void goToCreateRequest() {
        changeScene("create-request-view.fxml");
    }

    @FXML
    public void goToWriters() {
        changeScene("writers-view.fxml");
    }

    @FXML
    public void goToUserOrders() {
        changeScene("user-orders-view.fxml");
    }

    @FXML
    public void goToUserHistory() {
        changeScene("user-history-view.fxml");
    }

    @FXML
    public void logout() {
        if (ControllerHelper.confirm(
                "Log out",
                "Do you want to return to the login page?"
        )) {
            Session.clear();
            changeScene("login-view.fxml");
        }
    }

    protected void changeScene(String fxmlFile) {
        try {
            Main.changeScene(fxmlFile);
        } catch (Exception exception) {
            exception.printStackTrace();
            ControllerHelper.showError(exception.getMessage());
        }
    }
}
