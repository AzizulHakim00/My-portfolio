package com.assignmentwriterhire.controller;

import com.assignmentwriterhire.Main;
import com.assignmentwriterhire.session.Session;
import javafx.fxml.FXML;

public abstract class AdminNavigationController {

    @FXML
    public void goToAdminDashboard() {
        changeScene("admin-dashboard-view.fxml");
    }

    @FXML
    public void goToManageUsers() {
        changeScene("manage-users-view.fxml");
    }

    @FXML
    public void goToManageWriters() {
        changeScene("manage-writers-view.fxml");
    }

    @FXML
    public void goToManageRequests() {
        changeScene("manage-requests-view.fxml");
    }

    @FXML
    public void goToManageOrders() {
        changeScene("manage-orders-view.fxml");
    }

    @FXML
    public void goToSystemHistory() {
        changeScene("system-history-view.fxml");
    }

    @FXML
    public void logout() {
        if (ControllerHelper.confirm(
                "Log out",
                "Do you want to return to the login page?"
        )) {
            Session.clear();
            changeScene("login-view.fxml");
        }
    }

    protected void changeScene(String fxmlFile) {
        try {
            Main.changeScene(fxmlFile);
        } catch (Exception exception) {
            exception.printStackTrace();
            ControllerHelper.showError(exception.getMessage());
        }
    }
}
