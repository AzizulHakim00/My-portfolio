@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ========================================
echo   Assignment Writer Hire
echo ========================================
echo.

where java >nul 2>nul
if errorlevel 1 (
    echo Java was not found. Install a JDK and try again.
    pause
    exit /b 1
)

if not defined JAVA_HOME (
    for /f "tokens=2 delims==" %%A in ('java -XshowSettings:properties -version 2^>^&1 ^| findstr /C:"java.home ="') do set "DETECTED_JAVA_HOME=%%A"
    for /f "tokens=*" %%A in ("!DETECTED_JAVA_HOME!") do set "JAVA_HOME=%%A"
)

echo Java home: %JAVA_HOME%
echo.
echo Make sure MySQL Server is running.
echo MySQL username: root
echo MySQL password: password
echo.

call mvnw.cmd -U clean javafx:run

echo.
if errorlevel 1 (
    echo The project stopped with an error. Read the message above.
) else (
    echo The application closed normally.
)
pause
