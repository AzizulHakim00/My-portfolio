package com.assignmentwriterhire.controller;

import com.assignmentwriterhire.model.User;
import com.assignmentwriterhire.model.Writer;
import com.assignmentwriterhire.services.HistoryService;
import com.assignmentwriterhire.services.WriterService;
import com.assignmentwriterhire.session.Session;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class ManageWritersController extends AdminNavigationController {

    @FXML
    private TableView<Writer> writerTable;

    @FXML
    private TableColumn<Writer, Integer> idColumn;

    @FXML
    private TableColumn<Writer, String> nameColumn;

    @FXML
    private TableColumn<Writer, String> specialtyColumn;

    @FXML
    private TableColumn<Writer, Integer> experienceColumn;

    @FXML
    private TableColumn<Writer, Double> ratingColumn;

    @FXML
    private TableColumn<Writer, Double> rateColumn;

    @FXML
    private TableColumn<Writer, String> availabilityColumn;

    @FXML
    private TextField nameField;

    @FXML
    private TextField specialtyField;

    @FXML
    private TextField experienceField;

    @FXML
    private TextField ratingField;

    @FXML
    private TextField rateField;

    @FXML
    private ComboBox<String> availabilityComboBox;

    @FXML
    private Label messageLabel;

    private final WriterService writerService = new WriterService();
    private final HistoryService historyService = new HistoryService();

    @FXML
    private void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        specialtyColumn.setCellValueFactory(
                new PropertyValueFactory<>("specialty")
        );
        experienceColumn.setCellValueFactory(
                new PropertyValueFactory<>("experience")
        );
        ratingColumn.setCellValueFactory(
                new PropertyValueFactory<>("rating")
        );
        rateColumn.setCellValueFactory(new PropertyValueFactory<>("rate"));
        availabilityColumn.setCellValueFactory(
                new PropertyValueFactory<>("availabilityText")
        );

        availabilityComboBox.getItems().addAll(
                "Available",
                "Unavailable"
        );
        availabilityComboBox.setValue("Available");

        writerTable.getSelectionModel()
                .selectedItemProperty()
                .addListener((observable, oldWriter, newWriter) ->
                        fillForm(newWriter)
                );

        loadWriters();
    }

    @FXML
    private void loadWriters() {
        try {
            writerTable.setItems(FXCollections.observableArrayList(
                    writerService.getAllWriters()
            ));
            messageLabel.setText("");
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("Writers could not be loaded.");
        }
    }

    @FXML
    private void addWriter() {
        Writer writer = readForm();
        if (writer == null) {
            return;
        }

        try {
            writerService.addWriter(writer);
            addAdminHistory(
                    "Writer added",
                    writer.getName() + " was added"
            );
            clearForm();
            loadWriters();
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("The writer could not be added.");
        }
    }

    @FXML
    private void updateWriter() {
        Writer selectedWriter = writerTable
                .getSelectionModel().getSelectedItem();

        if (selectedWriter == null) {
            messageLabel.setText("Select a writer first.");
            return;
        }

        Writer writer = readForm();
        if (writer == null) {
            return;
        }
        writer.setId(selectedWriter.getId());

        try {
            writerService.updateWriter(writer);
            addAdminHistory(
                    "Writer updated",
                    writer.getName() + " was updated"
            );
            clearForm();
            loadWriters();
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("The writer could not be updated.");
        }
    }

    @FXML
    private void deleteWriter() {
        Writer selectedWriter = writerTable
                .getSelectionModel().getSelectedItem();

        if (selectedWriter == null) {
            messageLabel.setText("Select a writer first.");
            return;
        }

        if (!ControllerHelper.confirm(
                "Delete writer",
                "Delete " + selectedWriter.getName() + "?"
        )) {
            return;
        }

        try {
            writerService.deleteWriter(selectedWriter.getId());
            addAdminHistory(
                    "Writer deleted",
                    selectedWriter.getName() + " was deleted"
            );
            clearForm();
            loadWriters();
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText(
                    "This writer may be connected to an existing order."
            );
        }
    }

    @FXML
    private void clearForm() {
        writerTable.getSelectionModel().clearSelection();
        nameField.clear();
        specialtyField.clear();
        experienceField.clear();
        ratingField.clear();
        rateField.clear();
        availabilityComboBox.setValue("Available");
        messageLabel.setText("");
    }

    private Writer readForm() {
        String name = nameField.getText().trim();
        String specialty = specialtyField.getText().trim();
        String experienceText = experienceField.getText().trim();
        String ratingText = ratingField.getText().trim();
        String rateText = rateField.getText().trim();

        if (name.isEmpty()
                || specialty.isEmpty()
                || experienceText.isEmpty()
                || ratingText.isEmpty()
                || rateText.isEmpty()) {
            messageLabel.setText("Complete all writer fields.");
            return null;
        }

        try {
            int experience = Integer.parseInt(experienceText);
            double rating = Double.parseDouble(ratingText);
            double rate = Double.parseDouble(rateText);

            if (experience < 0
                    || rating < 0
                    || rating > 5
                    || rate <= 0) {
                messageLabel.setText("Check experience, rating and rate.");
                return null;
            }

            return new Writer(
                    0,
                    name,
                    specialty,
                    experience,
                    rating,
                    rate,
                    "Available".equals(availabilityComboBox.getValue())
            );
        } catch (NumberFormatException exception) {
            messageLabel.setText("Experience, rating and rate must be numbers.");
            return null;
        }
    }

    private void fillForm(Writer writer) {
        if (writer == null) {
            return;
        }

        nameField.setText(writer.getName());
        specialtyField.setText(writer.getSpecialty());
        experienceField.setText(String.valueOf(writer.getExperience()));
        ratingField.setText(String.valueOf(writer.getRating()));
        rateField.setText(String.valueOf(writer.getRate()));
        availabilityComboBox.setValue(writer.getAvailabilityText());
    }

    private void addAdminHistory(String action, String details)
            throws Exception {
        User admin = Session.getCurrentUser();
        historyService.addHistory(
                0,
                admin.getFullName(),
                action,
                details
        );
    }
}
