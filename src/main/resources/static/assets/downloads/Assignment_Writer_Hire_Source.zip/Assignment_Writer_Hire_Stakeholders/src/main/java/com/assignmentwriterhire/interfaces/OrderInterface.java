package com.assignmentwriterhire.interfaces;

import com.assignmentwriterhire.model.Order;

import java.util.List;

public interface OrderInterface {

    void createOrder(
            int userId,
            int assignmentId,
            int writerId,
            double price
    ) throws Exception;

    List<Order> getOrdersByUser(int userId) throws Exception;

    List<Order> getAllOrders() throws Exception;

    void updateOrder(int orderId, String status, int progress) throws Exception;

    void cancelOrder(int orderId, int assignmentId) throws Exception;

    int countActiveOrdersByUser(int userId) throws Exception;

    int countAllOrders() throws Exception;
}
