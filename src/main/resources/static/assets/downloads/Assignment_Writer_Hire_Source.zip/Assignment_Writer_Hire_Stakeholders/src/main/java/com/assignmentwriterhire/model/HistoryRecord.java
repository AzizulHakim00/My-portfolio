package com.assignmentwriterhire.model;

public class HistoryRecord {

    private int id;
    private int userId;
    private String actor;
    private String action;
    private String details;
    private String actionDate;

    public HistoryRecord(
            int id,
            int userId,
            String actor,
            String action,
            String details,
            String actionDate
    ) {
        this.id = id;
        this.userId = userId;
        this.actor = actor;
        this.action = action;
        this.details = details;
        this.actionDate = actionDate;
    }

    public int getId() {
        return id;
    }

    public int getUserId() {
        return userId;
    }

    public String getActor() {
        return actor;
    }

    public String getAction() {
        return action;
    }

    public String getDetails() {
        return details;
    }

    public String getActionDate() {
        return actionDate;
    }
}
