package com.assignmentwriterhire.controller;

import com.assignmentwriterhire.model.Order;
import com.assignmentwriterhire.model.User;
import com.assignmentwriterhire.services.HistoryService;
import com.assignmentwriterhire.services.OrderService;
import com.assignmentwriterhire.session.Session;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class UserOrdersController extends UserNavigationController {

    @FXML
    private TableView<Order> orderTable;

    @FXML
    private TableColumn<Order, Integer> idColumn;

    @FXML
    private TableColumn<Order, String> assignmentColumn;

    @FXML
    private TableColumn<Order, String> writerColumn;

    @FXML
    private TableColumn<Order, Double> priceColumn;

    @FXML
    private TableColumn<Order, String> statusColumn;

    @FXML
    private TableColumn<Order, String> progressColumn;

    @FXML
    private TableColumn<Order, String> dateColumn;

    @FXML
    private Label messageLabel;

    private final OrderService orderService = new OrderService();
    private final HistoryService historyService = new HistoryService();

    @FXML
    private void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        assignmentColumn.setCellValueFactory(
                new PropertyValueFactory<>("assignmentTitle")
        );
        writerColumn.setCellValueFactory(
                new PropertyValueFactory<>("writerName")
        );
        priceColumn.setCellValueFactory(
                new PropertyValueFactory<>("price")
        );
        statusColumn.setCellValueFactory(
                new PropertyValueFactory<>("status")
        );
        progressColumn.setCellValueFactory(
                new PropertyValueFactory<>("progressText")
        );
        dateColumn.setCellValueFactory(
                new PropertyValueFactory<>("createdAt")
        );
        loadOrders();
    }

    @FXML
    private void loadOrders() {
        User user = Session.getCurrentUser();
        if (user == null) {
            changeScene("login-view.fxml");
            return;
        }

        try {
            orderTable.setItems(FXCollections.observableArrayList(
                    orderService.getOrdersByUser(user.getId())
            ));
            messageLabel.setText("");
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("Orders could not be loaded.");
        }
    }

    @FXML
    private void cancelSelectedOrder() {
        User user = Session.getCurrentUser();
        Order order = orderTable.getSelectionModel().getSelectedItem();

        if (order == null) {
            messageLabel.setText("Select an order first.");
            return;
        }

        if (!ControllerHelper.confirm(
                "Cancel order",
                "Cancel the selected order and reopen its request?"
        )) {
            return;
        }

        try {
            orderService.cancelOrder(
                    order.getId(),
                    order.getAssignmentId()
            );
            historyService.addHistory(
                    user.getId(),
                    user.getFullName(),
                    "Order cancelled",
                    order.getAssignmentTitle() + " was cancelled"
            );
            loadOrders();
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText(exception.getMessage());
        }
    }
}
