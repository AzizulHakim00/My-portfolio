package com.assignmentwriterhire.services;

import com.assignmentwriterhire.interfaces.AuthInterface;
import com.assignmentwriterhire.model.User;
import com.assignmentwriterhire.singleton.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;

public class AuthService implements AuthInterface {

    @Override
    public User login(String username, String password) throws Exception {
        String sql = """
                SELECT id, full_name, username, password, role, status
                FROM users
                WHERE username = ? AND password = ?
                """;

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, username);
            statement.setString(2, password);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new User(
                            resultSet.getInt("id"),
                            resultSet.getString("full_name"),
                            resultSet.getString("username"),
                            resultSet.getString("password"),
                            resultSet.getString("role"),
                            resultSet.getString("status")
                    );
                }
            }
        }
        return null;
    }

    @Override
    public boolean register(
            String fullName,
            String username,
            String password
    ) throws Exception {
        String sql = """
                INSERT INTO users(
                    full_name, username, password, role, status
                ) VALUES (?, ?, ?, 'User', 'Active')
                """;

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, fullName);
            statement.setString(2, username);
            statement.setString(3, password);
            return statement.executeUpdate() > 0;
        } catch (SQLIntegrityConstraintViolationException exception) {
            return false;
        }
    }
}
