package com.assignmentwriterhire.services;

import com.assignmentwriterhire.interfaces.WriterInterface;
import com.assignmentwriterhire.model.Writer;
import com.assignmentwriterhire.singleton.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class WriterService implements WriterInterface {

    @Override
    public List<Writer> getAllWriters() throws Exception {
        return loadWriters("SELECT * FROM writers ORDER BY name");
    }

    @Override
    public List<Writer> getAvailableWriters() throws Exception {
        return loadWriters(
                "SELECT * FROM writers "
                        + "WHERE available = TRUE ORDER BY rating DESC"
        );
    }

    @Override
    public void addWriter(Writer writer) throws Exception {
        String sql = """
                INSERT INTO writers(
                    name, specialty, experience, rating, rate, available
                ) VALUES (?, ?, ?, ?, ?, ?)
                """;

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            setWriterValues(statement, writer);
            statement.executeUpdate();
        }
    }

    @Override
    public void updateWriter(Writer writer) throws Exception {
        String sql = """
                UPDATE writers
                SET name = ?, specialty = ?, experience = ?,
                    rating = ?, rate = ?, available = ?
                WHERE id = ?
                """;

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            setWriterValues(statement, writer);
            statement.setInt(7, writer.getId());
            statement.executeUpdate();
        }
    }

    @Override
    public void deleteWriter(int writerId) throws Exception {
        String sql = "DELETE FROM writers WHERE id = ?";

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, writerId);
            statement.executeUpdate();
        }
    }

    @Override
    public int countAvailableWriters() throws Exception {
        String sql = "SELECT COUNT(*) FROM writers WHERE available = TRUE";

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            return resultSet.next() ? resultSet.getInt(1) : 0;
        }
    }

    private List<Writer> loadWriters(String sql) throws Exception {
        List<Writer> writers = new ArrayList<>();

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                writers.add(new Writer(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("specialty"),
                        resultSet.getInt("experience"),
                        resultSet.getDouble("rating"),
                        resultSet.getDouble("rate"),
                        resultSet.getBoolean("available")
                ));
            }
        }
        return writers;
    }

    private void setWriterValues(
            PreparedStatement statement,
            Writer writer
    ) throws Exception {
        statement.setString(1, writer.getName());
        statement.setString(2, writer.getSpecialty());
        statement.setInt(3, writer.getExperience());
        statement.setDouble(4, writer.getRating());
        statement.setDouble(5, writer.getRate());
        statement.setBoolean(6, writer.isAvailable());
    }
}
