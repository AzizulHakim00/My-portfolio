package com.assignmentwriterhire.controller;

import com.assignmentwriterhire.model.Order;
import com.assignmentwriterhire.model.User;
import com.assignmentwriterhire.services.HistoryService;
import com.assignmentwriterhire.services.OrderService;
import com.assignmentwriterhire.session.Session;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ManageOrdersController extends AdminNavigationController {

    @FXML
    private TableView<Order> orderTable;

    @FXML
    private TableColumn<Order, Integer> idColumn;

    @FXML
    private TableColumn<Order, String> userColumn;

    @FXML
    private TableColumn<Order, String> assignmentColumn;

    @FXML
    private TableColumn<Order, String> writerColumn;

    @FXML
    private TableColumn<Order, Double> priceColumn;

    @FXML
    private TableColumn<Order, String> statusColumn;

    @FXML
    private TableColumn<Order, String> progressColumn;

    @FXML
    private ComboBox<String> statusComboBox;

    @FXML
    private Spinner<Integer> progressSpinner;

    @FXML
    private Label messageLabel;

    private final OrderService orderService = new OrderService();
    private final HistoryService historyService = new HistoryService();

    @FXML
    private void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        userColumn.setCellValueFactory(
                new PropertyValueFactory<>("userName")
        );
        assignmentColumn.setCellValueFactory(
                new PropertyValueFactory<>("assignmentTitle")
        );
        writerColumn.setCellValueFactory(
                new PropertyValueFactory<>("writerName")
        );
        priceColumn.setCellValueFactory(
                new PropertyValueFactory<>("price")
        );
        statusColumn.setCellValueFactory(
                new PropertyValueFactory<>("status")
        );
        progressColumn.setCellValueFactory(
                new PropertyValueFactory<>("progressText")
        );

        statusComboBox.getItems().addAll(
                "Pending",
                "In Progress",
                "Submitted",
                "Completed",
                "Cancelled"
        );
        statusComboBox.setValue("Pending");
        progressSpinner.setValueFactory(
                new SpinnerValueFactory.IntegerSpinnerValueFactory(
                        0,
                        100,
                        0,
                        10
                )
        );

        orderTable.getSelectionModel()
                .selectedItemProperty()
                .addListener((observable, oldOrder, newOrder) -> {
                    if (newOrder != null) {
                        statusComboBox.setValue(newOrder.getStatus());
                        progressSpinner.getValueFactory().setValue(
                                newOrder.getProgress()
                        );
                    }
                });

        loadOrders();
    }

    @FXML
    private void loadOrders() {
        try {
            orderTable.setItems(FXCollections.observableArrayList(
                    orderService.getAllOrders()
            ));
            messageLabel.setText("");
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("Orders could not be loaded.");
        }
    }

    @FXML
    private void updateSelectedOrder() {
        Order order = orderTable.getSelectionModel().getSelectedItem();

        if (order == null) {
            messageLabel.setText("Select an order first.");
            return;
        }

        String status = statusComboBox.getValue();
        int progress = progressSpinner.getValue();

        if ("Completed".equals(status)) {
            progress = 100;
        } else if ("Cancelled".equals(status)) {
            progress = 0;
        }

        try {
            orderService.updateOrder(order.getId(), status, progress);
            User admin = Session.getCurrentUser();
            historyService.addHistory(
                    order.getUserId(),
                    admin.getFullName(),
                    "Order updated",
                    order.getAssignmentTitle()
                            + " changed to "
                            + status
                            + " ("
                            + progress
                            + "%)"
            );
            loadOrders();
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("The order could not be updated.");
        }
    }
}
