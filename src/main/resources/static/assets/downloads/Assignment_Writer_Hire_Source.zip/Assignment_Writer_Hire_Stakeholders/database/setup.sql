-- Assignment Writer Hire
-- MySQL reference schema
-- The Java application creates this database automatically.

CREATE DATABASE IF NOT EXISTS assignment_writer_hire_db
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE assignment_writer_hire_db;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Active'
);

CREATE TABLE writers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    specialty VARCHAR(100) NOT NULL,
    experience INT NOT NULL,
    rating DOUBLE NOT NULL,
    rate DOUBLE NOT NULL,
    available BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE assignment_requests (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    subject VARCHAR(100) NOT NULL,
    assignment_type VARCHAR(80) NOT NULL,
    deadline VARCHAR(30) NOT NULL,
    pages INT NOT NULL,
    budget DOUBLE NOT NULL,
    description TEXT,
    status VARCHAR(30) NOT NULL,
    created_at VARCHAR(30) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    assignment_id INT NOT NULL,
    writer_id INT NOT NULL,
    price DOUBLE NOT NULL,
    status VARCHAR(30) NOT NULL,
    progress INT NOT NULL DEFAULT 0,
    created_at VARCHAR(30) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (assignment_id) REFERENCES assignment_requests(id),
    FOREIGN KEY (writer_id) REFERENCES writers(id)
);

CREATE TABLE history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NULL,
    actor VARCHAR(100) NOT NULL,
    action VARCHAR(80) NOT NULL,
    details VARCHAR(255) NOT NULL,
    action_date VARCHAR(30) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
