package com.assignmentwriterhire.services;

import com.assignmentwriterhire.interfaces.HistoryInterface;
import com.assignmentwriterhire.model.HistoryRecord;
import com.assignmentwriterhire.singleton.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class HistoryService implements HistoryInterface {

    private static final DateTimeFormatter FORMATTER =
            DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a");

    @Override
    public void addHistory(
            int userId,
            String actor,
            String action,
            String details
    ) throws Exception {
        String sql = """
                INSERT INTO history(
                    user_id, actor, action, details, action_date
                ) VALUES (?, ?, ?, ?, ?)
                """;

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            if (userId > 0) {
                statement.setInt(1, userId);
            } else {
                statement.setNull(1, java.sql.Types.INTEGER);
            }
            statement.setString(2, actor);
            statement.setString(3, action);
            statement.setString(4, details);
            statement.setString(
                    5,
                    LocalDateTime.now().format(FORMATTER)
            );
            statement.executeUpdate();
        }
    }

    @Override
    public List<HistoryRecord> getHistoryByUser(int userId) throws Exception {
        String sql = """
                SELECT id, user_id, actor, action, details, action_date
                FROM history
                WHERE user_id = ?
                ORDER BY id DESC
                """;

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, userId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return readRecords(resultSet);
            }
        }
    }

    @Override
    public List<HistoryRecord> getAllHistory() throws Exception {
        String sql = """
                SELECT id, user_id, actor, action, details, action_date
                FROM history
                ORDER BY id DESC
                """;

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            return readRecords(resultSet);
        }
    }

    private List<HistoryRecord> readRecords(ResultSet resultSet)
            throws Exception {
        List<HistoryRecord> records = new ArrayList<>();
        while (resultSet.next()) {
            records.add(new HistoryRecord(
                    resultSet.getInt("id"),
                    resultSet.getInt("user_id"),
                    resultSet.getString("actor"),
                    resultSet.getString("action"),
                    resultSet.getString("details"),
                    resultSet.getString("action_date")
            ));
        }
        return records;
    }
}
