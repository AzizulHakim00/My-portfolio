package com.assignmentwriterhire.controller;

import com.assignmentwriterhire.model.AssignmentRequest;
import com.assignmentwriterhire.model.User;
import com.assignmentwriterhire.model.Writer;
import com.assignmentwriterhire.services.AssignmentService;
import com.assignmentwriterhire.services.HistoryService;
import com.assignmentwriterhire.services.OrderService;
import com.assignmentwriterhire.services.WriterService;
import com.assignmentwriterhire.session.Session;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class WritersController extends UserNavigationController {

    @FXML
    private TextField searchField;

    @FXML
    private TableView<Writer> writerTable;

    @FXML
    private TableColumn<Writer, String> nameColumn;

    @FXML
    private TableColumn<Writer, String> specialtyColumn;

    @FXML
    private TableColumn<Writer, Integer> experienceColumn;

    @FXML
    private TableColumn<Writer, Double> ratingColumn;

    @FXML
    private TableColumn<Writer, Double> rateColumn;

    @FXML
    private ComboBox<AssignmentRequest> requestComboBox;

    @FXML
    private Label selectedWriterLabel;

    @FXML
    private Label priceLabel;

    @FXML
    private Label messageLabel;

    private final WriterService writerService = new WriterService();
    private final AssignmentService assignmentService =
            new AssignmentService();
    private final OrderService orderService = new OrderService();
    private final HistoryService historyService = new HistoryService();

    private ObservableList<Writer> writerList;

    @FXML
    private void initialize() {
        nameColumn.setCellValueFactory(
                new PropertyValueFactory<>("name")
        );
        specialtyColumn.setCellValueFactory(
                new PropertyValueFactory<>("specialty")
        );
        experienceColumn.setCellValueFactory(
                new PropertyValueFactory<>("experience")
        );
        ratingColumn.setCellValueFactory(
                new PropertyValueFactory<>("rating")
        );
        rateColumn.setCellValueFactory(
                new PropertyValueFactory<>("rate")
        );

        loadData();

        writerTable.getSelectionModel()
                .selectedItemProperty()
                .addListener((observable, oldWriter, newWriter) -> {
                    showWriterDetails(newWriter);
                    updatePrice();
                });

        requestComboBox.valueProperty().addListener(
                (observable, oldRequest, newRequest) -> updatePrice()
        );
    }

    private void loadData() {
        User user = Session.getCurrentUser();
        if (user == null) {
            changeScene("login-view.fxml");
            return;
        }

        try {
            writerList = FXCollections.observableArrayList(
                    writerService.getAvailableWriters()
            );
            FilteredList<Writer> filteredWriters =
                    new FilteredList<>(writerList, writer -> true);
            writerTable.setItems(filteredWriters);

            searchField.textProperty().addListener(
                    (observable, oldValue, newValue) -> {
                        String text = newValue == null
                                ? ""
                                : newValue.toLowerCase().trim();
                        filteredWriters.setPredicate(writer ->
                                text.isEmpty()
                                        || writer.getName()
                                        .toLowerCase().contains(text)
                                        || writer.getSpecialty()
                                        .toLowerCase().contains(text)
                        );
                    }
            );

            requestComboBox.setItems(
                    FXCollections.observableArrayList(
                            assignmentService.getOpenRequestsByUser(
                                    user.getId()
                            )
                    )
            );

            if (!writerList.isEmpty()) {
                writerTable.getSelectionModel().selectFirst();
            }
            if (!requestComboBox.getItems().isEmpty()) {
                requestComboBox.getSelectionModel().selectFirst();
            }
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("Writer information could not be loaded.");
        }
    }

    private void showWriterDetails(Writer writer) {
        if (writer == null) {
            selectedWriterLabel.setText("No writer selected");
            return;
        }

        selectedWriterLabel.setText(
                writer.getName()
                        + " · "
                        + writer.getSpecialty()
                        + " · "
                        + writer.getExperience()
                        + " years"
        );
    }

    private void updatePrice() {
        Writer writer = writerTable.getSelectionModel().getSelectedItem();
        AssignmentRequest request = requestComboBox.getValue();

        if (writer == null || request == null) {
            priceLabel.setText("Estimated price: —");
            return;
        }

        double price = writer.getRate() * request.getPages();
        priceLabel.setText(
                String.format("Estimated price: BDT %.0f", price)
        );
    }

    @FXML
    private void hireSelectedWriter() {
        User user = Session.getCurrentUser();
        Writer writer = writerTable.getSelectionModel().getSelectedItem();
        AssignmentRequest request = requestComboBox.getValue();

        if (user == null) {
            changeScene("login-view.fxml");
            return;
        }

        if (writer == null || request == null) {
            messageLabel.setText("Select both a request and a writer.");
            return;
        }

        double price = writer.getRate() * request.getPages();

        if (price > request.getBudget()) {
            boolean continueHire = ControllerHelper.confirm(
                    "Price is above budget",
                    String.format(
                            "The estimated price is BDT %.0f, but your budget is BDT %.0f. Continue?",
                            price,
                            request.getBudget()
                    )
            );
            if (!continueHire) {
                return;
            }
        }

        try {
            orderService.createOrder(
                    user.getId(),
                    request.getId(),
                    writer.getId(),
                    price
            );
            historyService.addHistory(
                    user.getId(),
                    user.getFullName(),
                    "Writer hired",
                    writer.getName() + " was hired for " + request.getTitle()
            );
            ControllerHelper.showInfo(
                    "Order created",
                    "The writer was assigned to your request."
            );
            loadData();
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText(exception.getMessage());
        }
    }
}
