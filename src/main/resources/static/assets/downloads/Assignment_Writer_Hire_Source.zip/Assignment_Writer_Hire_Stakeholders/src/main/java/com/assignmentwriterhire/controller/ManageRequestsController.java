package com.assignmentwriterhire.controller;

import com.assignmentwriterhire.model.AssignmentRequest;
import com.assignmentwriterhire.model.User;
import com.assignmentwriterhire.services.AssignmentService;
import com.assignmentwriterhire.services.HistoryService;
import com.assignmentwriterhire.session.Session;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ManageRequestsController extends AdminNavigationController {

    @FXML
    private TableView<AssignmentRequest> requestTable;

    @FXML
    private TableColumn<AssignmentRequest, Integer> idColumn;

    @FXML
    private TableColumn<AssignmentRequest, String> userColumn;

    @FXML
    private TableColumn<AssignmentRequest, String> titleColumn;

    @FXML
    private TableColumn<AssignmentRequest, String> subjectColumn;

    @FXML
    private TableColumn<AssignmentRequest, String> typeColumn;

    @FXML
    private TableColumn<AssignmentRequest, String> deadlineColumn;

    @FXML
    private TableColumn<AssignmentRequest, Double> budgetColumn;

    @FXML
    private TableColumn<AssignmentRequest, String> statusColumn;

    @FXML
    private ComboBox<String> statusComboBox;

    @FXML
    private Label messageLabel;

    private final AssignmentService assignmentService =
            new AssignmentService();
    private final HistoryService historyService = new HistoryService();

    @FXML
    private void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        userColumn.setCellValueFactory(
                new PropertyValueFactory<>("userName")
        );
        titleColumn.setCellValueFactory(
                new PropertyValueFactory<>("title")
        );
        subjectColumn.setCellValueFactory(
                new PropertyValueFactory<>("subject")
        );
        typeColumn.setCellValueFactory(
                new PropertyValueFactory<>("assignmentType")
        );
        deadlineColumn.setCellValueFactory(
                new PropertyValueFactory<>("deadline")
        );
        budgetColumn.setCellValueFactory(
                new PropertyValueFactory<>("budget")
        );
        statusColumn.setCellValueFactory(
                new PropertyValueFactory<>("status")
        );

        statusComboBox.getItems().addAll(
                "Open",
                "Assigned",
                "In Review",
                "Completed",
                "Cancelled"
        );
        statusComboBox.setValue("Open");

        requestTable.getSelectionModel()
                .selectedItemProperty()
                .addListener((observable, oldRequest, newRequest) -> {
                    if (newRequest != null) {
                        statusComboBox.setValue(newRequest.getStatus());
                    }
                });

        loadRequests();
    }

    @FXML
    private void loadRequests() {
        try {
            requestTable.setItems(FXCollections.observableArrayList(
                    assignmentService.getAllRequests()
            ));
            messageLabel.setText("");
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("Requests could not be loaded.");
        }
    }

    @FXML
    private void updateRequestStatus() {
        AssignmentRequest request = requestTable
                .getSelectionModel().getSelectedItem();

        if (request == null) {
            messageLabel.setText("Select a request first.");
            return;
        }

        try {
            assignmentService.updateStatus(
                    request.getId(),
                    statusComboBox.getValue()
            );
            addHistory(
                    request.getUserId(),
                    "Request status changed",
                    request.getTitle()
                            + " changed to "
                            + statusComboBox.getValue()
            );
            loadRequests();
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("The status could not be updated.");
        }
    }

    @FXML
    private void deleteRequest() {
        AssignmentRequest request = requestTable
                .getSelectionModel().getSelectedItem();

        if (request == null) {
            messageLabel.setText("Select a request first.");
            return;
        }

        if (!ControllerHelper.confirm(
                "Delete request",
                "Delete " + request.getTitle() + "?"
        )) {
            return;
        }

        try {
            addHistory(
                    request.getUserId(),
                    "Request deleted",
                    request.getTitle() + " was deleted by admin"
            );
            assignmentService.deleteRequest(request.getId());
            loadRequests();
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("The request could not be deleted.");
        }
    }

    private void addHistory(
            int userId,
            String action,
            String details
    ) throws Exception {
        User admin = Session.getCurrentUser();
        historyService.addHistory(
                userId,
                admin.getFullName(),
                action,
                details
        );
    }
}
