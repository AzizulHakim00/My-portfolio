package com.assignmentwriterhire.controller;

import com.assignmentwriterhire.model.User;
import com.assignmentwriterhire.services.AssignmentService;
import com.assignmentwriterhire.services.OrderService;
import com.assignmentwriterhire.services.WriterService;
import com.assignmentwriterhire.session.Session;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class UserDashboardController extends UserNavigationController {

    @FXML
    private Label welcomeLabel;

    @FXML
    private Label openRequestLabel;

    @FXML
    private Label activeOrderLabel;

    @FXML
    private Label writerCountLabel;

    private final AssignmentService assignmentService =
            new AssignmentService();
    private final OrderService orderService = new OrderService();
    private final WriterService writerService = new WriterService();

    @FXML
    private void initialize() {
        User user = Session.getCurrentUser();
        if (user == null) {
            changeScene("login-view.fxml");
            return;
        }

        welcomeLabel.setText("Welcome, " + user.getFullName());

        try {
            openRequestLabel.setText(String.valueOf(
                    assignmentService.countOpenRequestsByUser(user.getId())
            ));
            activeOrderLabel.setText(String.valueOf(
                    orderService.countActiveOrdersByUser(user.getId())
            ));
            writerCountLabel.setText(String.valueOf(
                    writerService.countAvailableWriters()
            ));
        } catch (Exception exception) {
            exception.printStackTrace();
            ControllerHelper.showError(
                    "Dashboard information could not be loaded."
            );
        }
    }
}
