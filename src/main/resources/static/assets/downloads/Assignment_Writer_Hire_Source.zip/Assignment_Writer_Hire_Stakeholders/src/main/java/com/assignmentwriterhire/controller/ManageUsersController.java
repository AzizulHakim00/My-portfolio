package com.assignmentwriterhire.controller;

import com.assignmentwriterhire.model.User;
import com.assignmentwriterhire.services.HistoryService;
import com.assignmentwriterhire.services.UserService;
import com.assignmentwriterhire.session.Session;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ManageUsersController extends AdminNavigationController {

    @FXML
    private TableView<User> userTable;

    @FXML
    private TableColumn<User, Integer> idColumn;

    @FXML
    private TableColumn<User, String> nameColumn;

    @FXML
    private TableColumn<User, String> usernameColumn;

    @FXML
    private TableColumn<User, String> roleColumn;

    @FXML
    private TableColumn<User, String> statusColumn;

    @FXML
    private Label messageLabel;

    private final UserService userService = new UserService();
    private final HistoryService historyService = new HistoryService();

    @FXML
    private void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(
                new PropertyValueFactory<>("fullName")
        );
        usernameColumn.setCellValueFactory(
                new PropertyValueFactory<>("username")
        );
        roleColumn.setCellValueFactory(
                new PropertyValueFactory<>("role")
        );
        statusColumn.setCellValueFactory(
                new PropertyValueFactory<>("status")
        );
        loadUsers();
    }

    @FXML
    private void loadUsers() {
        try {
            userTable.setItems(FXCollections.observableArrayList(
                    userService.getAllUsers()
            ));
            messageLabel.setText("");
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("Users could not be loaded.");
        }
    }

    @FXML
    private void toggleSelectedUser() {
        User selectedUser = userTable.getSelectionModel().getSelectedItem();
        User admin = Session.getCurrentUser();

        if (selectedUser == null) {
            messageLabel.setText("Select a user first.");
            return;
        }

        if ("Admin".equalsIgnoreCase(selectedUser.getRole())) {
            messageLabel.setText("The administrator account cannot be blocked.");
            return;
        }

        String newStatus = "Active".equalsIgnoreCase(
                selectedUser.getStatus()
        ) ? "Blocked" : "Active";

        try {
            userService.updateStatus(selectedUser.getId(), newStatus);
            historyService.addHistory(
                    selectedUser.getId(),
                    admin.getFullName(),
                    "User status changed",
                    selectedUser.getUsername() + " changed to " + newStatus
            );
            loadUsers();
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("The user status could not be changed.");
        }
    }
}
