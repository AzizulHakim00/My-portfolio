package com.assignmentwriterhire.singleton;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {

    private static DatabaseConnection instance;
    private Connection connection;

    private static final String DATABASE_NAME =
            "assignment_writer_hire_db";

    private static final String HOST_URL =
            "jdbc:mysql://localhost:3306/"
                    + "?useSSL=false"
                    + "&allowPublicKeyRetrieval=true"
                    + "&serverTimezone=UTC"
                    + "&useUnicode=true"
                    + "&characterEncoding=UTF-8";

    private static final String DATABASE_URL =
            "jdbc:mysql://localhost:3306/"
                    + DATABASE_NAME
                    + "?useSSL=false"
                    + "&allowPublicKeyRetrieval=true"
                    + "&serverTimezone=UTC"
                    + "&useUnicode=true"
                    + "&characterEncoding=UTF-8";

    private static final String USER = "root";
    private static final String PASSWORD = "password";
    private static final int SCHEMA_VERSION = 2;

    private DatabaseConnection() {
    }

    public static DatabaseConnection getInstance() {
        if (instance == null) {
            instance = new DatabaseConnection();
        }
        return instance;
    }

    public synchronized void setupDatabase() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");

        try (Connection hostConnection = DriverManager.getConnection(
                HOST_URL, USER, PASSWORD
        ); Statement statement = hostConnection.createStatement()) {

            statement.executeUpdate(
                    "CREATE DATABASE IF NOT EXISTS "
                            + DATABASE_NAME
                            + " CHARACTER SET utf8mb4"
                            + " COLLATE utf8mb4_unicode_ci"
            );
        }

        connection = DriverManager.getConnection(
                DATABASE_URL, USER, PASSWORD
        );

        prepareSchema();
        seedAccounts();
        seedWriters();
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                DATABASE_URL, USER, PASSWORD
        );
    }

    private void prepareSchema() throws SQLException {
        createMetaTable();

        int currentVersion = readSchemaVersion();
        if (currentVersion != SCHEMA_VERSION) {
            rebuildProjectTables();
        }

        createProjectTables();
        saveSchemaVersion();
    }

    private void createMetaTable() throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS app_meta (
                        meta_key VARCHAR(50) PRIMARY KEY,
                        meta_value VARCHAR(100) NOT NULL
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                    """);
        }
    }

    private int readSchemaVersion() throws SQLException {
        String sql = "SELECT meta_value FROM app_meta "
                + "WHERE meta_key = 'schema_version'";

        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            if (resultSet.next()) {
                try {
                    return Integer.parseInt(resultSet.getString(1));
                } catch (NumberFormatException ignored) {
                    return 0;
                }
            }
        }
        return 0;
    }

    private void rebuildProjectTables() throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.execute("SET FOREIGN_KEY_CHECKS = 0");
            statement.executeUpdate("DROP TABLE IF EXISTS history");
            statement.executeUpdate("DROP TABLE IF EXISTS orders");
            statement.executeUpdate("DROP TABLE IF EXISTS assignment_requests");
            statement.executeUpdate("DROP TABLE IF EXISTS assignments");
            statement.executeUpdate("DROP TABLE IF EXISTS writers");
            statement.executeUpdate("DROP TABLE IF EXISTS users");
            statement.execute("SET FOREIGN_KEY_CHECKS = 1");
        }
    }

    private void createProjectTables() throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS users (
                        id INT PRIMARY KEY AUTO_INCREMENT,
                        full_name VARCHAR(100) NOT NULL,
                        username VARCHAR(50) NOT NULL UNIQUE,
                        password VARCHAR(100) NOT NULL,
                        role VARCHAR(20) NOT NULL,
                        status VARCHAR(20) NOT NULL DEFAULT 'Active'
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                    """);

            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS writers (
                        id INT PRIMARY KEY AUTO_INCREMENT,
                        name VARCHAR(100) NOT NULL,
                        specialty VARCHAR(100) NOT NULL,
                        experience INT NOT NULL,
                        rating DOUBLE NOT NULL,
                        rate DOUBLE NOT NULL,
                        available BOOLEAN NOT NULL DEFAULT TRUE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                    """);

            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS assignment_requests (
                        id INT PRIMARY KEY AUTO_INCREMENT,
                        user_id INT NOT NULL,
                        title VARCHAR(150) NOT NULL,
                        subject VARCHAR(100) NOT NULL,
                        assignment_type VARCHAR(80) NOT NULL,
                        deadline VARCHAR(30) NOT NULL,
                        pages INT NOT NULL,
                        budget DOUBLE NOT NULL,
                        description TEXT,
                        status VARCHAR(30) NOT NULL,
                        created_at VARCHAR(30) NOT NULL,
                        CONSTRAINT fk_request_user
                            FOREIGN KEY (user_id) REFERENCES users(id)
                            ON UPDATE CASCADE ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                    """);

            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS orders (
                        id INT PRIMARY KEY AUTO_INCREMENT,
                        user_id INT NOT NULL,
                        assignment_id INT NOT NULL,
                        writer_id INT NOT NULL,
                        price DOUBLE NOT NULL,
                        status VARCHAR(30) NOT NULL,
                        progress INT NOT NULL DEFAULT 0,
                        created_at VARCHAR(30) NOT NULL,
                        CONSTRAINT fk_order_user
                            FOREIGN KEY (user_id) REFERENCES users(id)
                            ON UPDATE CASCADE ON DELETE CASCADE,
                        CONSTRAINT fk_order_assignment
                            FOREIGN KEY (assignment_id)
                            REFERENCES assignment_requests(id)
                            ON UPDATE CASCADE ON DELETE CASCADE,
                        CONSTRAINT fk_order_writer
                            FOREIGN KEY (writer_id) REFERENCES writers(id)
                            ON UPDATE CASCADE ON DELETE RESTRICT
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                    """);

            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS history (
                        id INT PRIMARY KEY AUTO_INCREMENT,
                        user_id INT NULL,
                        actor VARCHAR(100) NOT NULL,
                        action VARCHAR(80) NOT NULL,
                        details VARCHAR(255) NOT NULL,
                        action_date VARCHAR(30) NOT NULL,
                        CONSTRAINT fk_history_user
                            FOREIGN KEY (user_id) REFERENCES users(id)
                            ON UPDATE CASCADE ON DELETE SET NULL
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                    """);
        }
    }

    private void saveSchemaVersion() throws SQLException {
        String sql = """
                INSERT INTO app_meta(meta_key, meta_value)
                VALUES ('schema_version', ?)
                ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value)
                """;

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, String.valueOf(SCHEMA_VERSION));
            statement.executeUpdate();
        }
    }

    private void seedAccounts() throws SQLException {
        String sql = """
                INSERT INTO users(
                    full_name, username, password, role, status
                ) VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    full_name = VALUES(full_name),
                    password = VALUES(password),
                    role = VALUES(role),
                    status = VALUES(status)
                """;

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, "System Administrator");
            statement.setString(2, "admin");
            statement.setString(3, "admin123");
            statement.setString(4, "Admin");
            statement.setString(5, "Active");
            statement.addBatch();

            statement.setString(1, "Demo Student");
            statement.setString(2, "student");
            statement.setString(3, "1234");
            statement.setString(4, "User");
            statement.setString(5, "Active");
            statement.addBatch();

            statement.executeBatch();
        }
    }

    private void seedWriters() throws SQLException {
        try (PreparedStatement countStatement = connection.prepareStatement(
                "SELECT COUNT(*) FROM writers"
        ); ResultSet resultSet = countStatement.executeQuery()) {

            if (resultSet.next() && resultSet.getInt(1) > 0) {
                return;
            }
        }

        String sql = """
                INSERT INTO writers(
                    name, specialty, experience, rating, rate, available
                ) VALUES (?, ?, ?, ?, ?, ?)
                """;

        Object[][] writers = {
                {"Ayesha Rahman", "Research Reports", 4, 4.9, 180.0, true},
                {"Nabil Hasan", "Java Programming", 3, 4.8, 220.0, true},
                {"Maliha Khan", "English and Essays", 5, 4.7, 150.0, true},
                {"Rafi Chowdhury", "Data Analysis", 4, 4.9, 250.0, true},
                {"Tasnim Islam", "Business Studies", 5, 4.6, 170.0, true},
                {"Sakib Ahmed", "Web Development", 3, 4.5, 210.0, true}
        };

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            for (Object[] writer : writers) {
                statement.setString(1, (String) writer[0]);
                statement.setString(2, (String) writer[1]);
                statement.setInt(3, (Integer) writer[2]);
                statement.setDouble(4, (Double) writer[3]);
                statement.setDouble(5, (Double) writer[4]);
                statement.setBoolean(6, (Boolean) writer[5]);
                statement.addBatch();
            }
            statement.executeBatch();
        }
    }
}
