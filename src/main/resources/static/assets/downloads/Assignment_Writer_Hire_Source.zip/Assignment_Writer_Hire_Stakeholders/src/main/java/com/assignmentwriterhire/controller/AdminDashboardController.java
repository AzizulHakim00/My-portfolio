package com.assignmentwriterhire.controller;

import com.assignmentwriterhire.model.User;
import com.assignmentwriterhire.services.AssignmentService;
import com.assignmentwriterhire.services.OrderService;
import com.assignmentwriterhire.services.UserService;
import com.assignmentwriterhire.services.WriterService;
import com.assignmentwriterhire.session.Session;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class AdminDashboardController extends AdminNavigationController {

    @FXML
    private Label welcomeLabel;

    @FXML
    private Label userCountLabel;

    @FXML
    private Label writerCountLabel;

    @FXML
    private Label requestCountLabel;

    @FXML
    private Label orderCountLabel;

    private final UserService userService = new UserService();
    private final WriterService writerService = new WriterService();
    private final AssignmentService assignmentService =
            new AssignmentService();
    private final OrderService orderService = new OrderService();

    @FXML
    private void initialize() {
        User user = Session.getCurrentUser();
        if (user == null || !"Admin".equalsIgnoreCase(user.getRole())) {
            changeScene("login-view.fxml");
            return;
        }

        welcomeLabel.setText("Admin panel · " + user.getFullName());

        try {
            userCountLabel.setText(String.valueOf(userService.countUsers()));
            writerCountLabel.setText(String.valueOf(
                    writerService.countAvailableWriters()
            ));
            requestCountLabel.setText(String.valueOf(
                    assignmentService.countAllRequests()
            ));
            orderCountLabel.setText(String.valueOf(
                    orderService.countAllOrders()
            ));
        } catch (Exception exception) {
            exception.printStackTrace();
            ControllerHelper.showError(
                    "Dashboard information could not be loaded."
            );
        }
    }
}
