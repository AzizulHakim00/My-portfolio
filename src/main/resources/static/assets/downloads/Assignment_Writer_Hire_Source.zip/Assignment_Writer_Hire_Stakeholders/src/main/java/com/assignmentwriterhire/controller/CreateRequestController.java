package com.assignmentwriterhire.controller;

import com.assignmentwriterhire.model.AssignmentRequest;
import com.assignmentwriterhire.model.User;
import com.assignmentwriterhire.services.AssignmentService;
import com.assignmentwriterhire.services.HistoryService;
import com.assignmentwriterhire.session.Session;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.time.LocalDate;

public class CreateRequestController extends UserNavigationController {

    @FXML
    private TextField titleField;

    @FXML
    private TextField subjectField;

    @FXML
    private ComboBox<String> typeComboBox;

    @FXML
    private DatePicker deadlinePicker;

    @FXML
    private Spinner<Integer> pagesSpinner;

    @FXML
    private TextField budgetField;

    @FXML
    private TextArea descriptionArea;

    @FXML
    private Label messageLabel;

    private final AssignmentService assignmentService =
            new AssignmentService();
    private final HistoryService historyService = new HistoryService();

    @FXML
    private void initialize() {
        typeComboBox.getItems().addAll(
                "Essay",
                "Report",
                "Presentation",
                "Programming",
                "Research Guidance",
                "Proofreading"
        );
        typeComboBox.setValue("Report");
        deadlinePicker.setValue(LocalDate.now().plusDays(7));
        pagesSpinner.setValueFactory(
                new SpinnerValueFactory.IntegerSpinnerValueFactory(
                        1,
                        100,
                        5
                )
        );
    }

    @FXML
    private void submitRequest() {
        User user = Session.getCurrentUser();
        if (user == null) {
            changeScene("login-view.fxml");
            return;
        }

        String title = titleField.getText().trim();
        String subject = subjectField.getText().trim();
        String type = typeComboBox.getValue();
        LocalDate deadline = deadlinePicker.getValue();
        String budgetText = budgetField.getText().trim();
        String description = descriptionArea.getText().trim();

        if (title.isEmpty()
                || subject.isEmpty()
                || type == null
                || deadline == null
                || budgetText.isEmpty()
                || description.isEmpty()) {
            messageLabel.setText("Complete all request details.");
            return;
        }

        if (deadline.isBefore(LocalDate.now())) {
            messageLabel.setText("The deadline cannot be in the past.");
            return;
        }

        double budget;
        try {
            budget = Double.parseDouble(budgetText);
        } catch (NumberFormatException exception) {
            messageLabel.setText("Budget must be a number.");
            return;
        }

        if (budget <= 0) {
            messageLabel.setText("Budget must be greater than zero.");
            return;
        }

        AssignmentRequest request = new AssignmentRequest();
        request.setUserId(user.getId());
        request.setTitle(title);
        request.setSubject(subject);
        request.setAssignmentType(type);
        request.setDeadline(deadline.toString());
        request.setPages(pagesSpinner.getValue());
        request.setBudget(budget);
        request.setDescription(description);

        try {
            assignmentService.createRequest(request);
            historyService.addHistory(
                    user.getId(),
                    user.getFullName(),
                    "Request created",
                    title + " was added"
            );
            clearForm();
            ControllerHelper.showInfo(
                    "Request saved",
                    "Your request is open. You can now choose a writer."
            );
        } catch (Exception exception) {
            exception.printStackTrace();
            messageLabel.setText("The request could not be saved.");
        }
    }

    @FXML
    private void clearForm() {
        titleField.clear();
        subjectField.clear();
        typeComboBox.setValue("Report");
        deadlinePicker.setValue(LocalDate.now().plusDays(7));
        pagesSpinner.getValueFactory().setValue(5);
        budgetField.clear();
        descriptionArea.clear();
        messageLabel.setText("");
    }
}
