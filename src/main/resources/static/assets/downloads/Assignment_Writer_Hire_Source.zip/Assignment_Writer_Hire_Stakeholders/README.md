# Assignment Writer Hire

A simple JavaFX and MySQL student project with two stakeholders:

1. User / Student
2. Administrator

The project follows a beginner-friendly controller, model, service, interface,
singleton and FXML structure.

## User functions

- Create a student account
- Log in
- Create an assignment request
- Browse available writers
- Hire a writer for an open request
- View and cancel personal orders
- View personal history

## Administrator functions

- Log in to a separate admin dashboard
- View dashboard totals
- Activate or block users
- Add, edit and delete writers
- Review and update requests
- Update order status and progress
- View complete system history

## Demo login

User:

- Username: `student`
- Password: `1234`

Admin:

- Username: `admin`
- Password: `admin123`

## MySQL configuration

- Host: `localhost`
- Port: `3306`
- Username: `root`
- Password: `password`
- Database: `assignment_writer_hire_db`

The database, tables, demo accounts and sample writers are created
automatically when the project starts.

## Easiest way to run on Windows

1. Start MySQL Server.
2. Double-click `RUN_PROJECT.bat`.
3. Wait for Maven to download dependencies on the first run.

`RUN_PROJECT.bat` detects the Java installation from the working `java`
command, so it does not require you to type JAVA_HOME every time.

## Run in IntelliJ IDEA

1. Open the folder containing `pom.xml`.
2. Allow IntelliJ to load the Maven project.
3. Select a JDK in Project Structure. JDK 21 is recommended.
4. Start MySQL Server.
5. Open `src/main/java/com/assignmentwriterhire/Main.java`.
6. Run the `main` method.

`Main` does not extend `Application` directly. This prevents the common
"JavaFX runtime components are missing" error when using IntelliJ's normal
Run button.

## Important note

This is a classroom demonstration project. Passwords are stored as plain text
to keep the code easy to understand. A production application should hash
passwords and use stronger security controls.
