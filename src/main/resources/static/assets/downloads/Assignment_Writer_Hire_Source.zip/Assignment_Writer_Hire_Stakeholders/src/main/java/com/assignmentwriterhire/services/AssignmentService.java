package com.assignmentwriterhire.services;

import com.assignmentwriterhire.interfaces.AssignmentInterface;
import com.assignmentwriterhire.model.AssignmentRequest;
import com.assignmentwriterhire.singleton.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class AssignmentService implements AssignmentInterface {

    private static final DateTimeFormatter FORMATTER =
            DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a");

    @Override
    public void createRequest(AssignmentRequest request) throws Exception {
        String sql = """
                INSERT INTO assignment_requests(
                    user_id, title, subject, assignment_type,
                    deadline, pages, budget, description,
                    status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Open', ?)
                """;

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, request.getUserId());
            statement.setString(2, request.getTitle());
            statement.setString(3, request.getSubject());
            statement.setString(4, request.getAssignmentType());
            statement.setString(5, request.getDeadline());
            statement.setInt(6, request.getPages());
            statement.setDouble(7, request.getBudget());
            statement.setString(8, request.getDescription());
            statement.setString(
                    9,
                    LocalDateTime.now().format(FORMATTER)
            );
            statement.executeUpdate();
        }
    }

    @Override
    public List<AssignmentRequest> getRequestsByUser(int userId)
            throws Exception {
        String sql = baseSelect()
                + " WHERE r.user_id = ? ORDER BY r.id DESC";

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, userId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return readRequests(resultSet);
            }
        }
    }

    @Override
    public List<AssignmentRequest> getOpenRequestsByUser(int userId)
            throws Exception {
        String sql = baseSelect()
                + " WHERE r.user_id = ? AND r.status = 'Open'"
                + " ORDER BY r.id DESC";

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, userId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return readRequests(resultSet);
            }
        }
    }

    @Override
    public List<AssignmentRequest> getAllRequests() throws Exception {
        String sql = baseSelect() + " ORDER BY r.id DESC";

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            return readRequests(resultSet);
        }
    }

    @Override
    public void updateStatus(int requestId, String status) throws Exception {
        String sql = "UPDATE assignment_requests SET status = ? WHERE id = ?";

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, status);
            statement.setInt(2, requestId);
            statement.executeUpdate();
        }
    }

    @Override
    public void deleteRequest(int requestId) throws Exception {
        String sql = "DELETE FROM assignment_requests WHERE id = ?";

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, requestId);
            statement.executeUpdate();
        }
    }

    @Override
    public int countOpenRequestsByUser(int userId) throws Exception {
        String sql = "SELECT COUNT(*) FROM assignment_requests "
                + "WHERE user_id = ? AND status = 'Open'";

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, userId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? resultSet.getInt(1) : 0;
            }
        }
    }

    @Override
    public int countAllRequests() throws Exception {
        String sql = "SELECT COUNT(*) FROM assignment_requests";

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            return resultSet.next() ? resultSet.getInt(1) : 0;
        }
    }

    private String baseSelect() {
        return """
                SELECT r.id, r.user_id, u.full_name AS user_name,
                       r.title, r.subject, r.assignment_type,
                       r.deadline, r.pages, r.budget, r.description,
                       r.status, r.created_at
                FROM assignment_requests r
                JOIN users u ON r.user_id = u.id
                """;
    }

    private List<AssignmentRequest> readRequests(ResultSet resultSet)
            throws Exception {
        List<AssignmentRequest> requests = new ArrayList<>();

        while (resultSet.next()) {
            requests.add(new AssignmentRequest(
                    resultSet.getInt("id"),
                    resultSet.getInt("user_id"),
                    resultSet.getString("user_name"),
                    resultSet.getString("title"),
                    resultSet.getString("subject"),
                    resultSet.getString("assignment_type"),
                    resultSet.getString("deadline"),
                    resultSet.getInt("pages"),
                    resultSet.getDouble("budget"),
                    resultSet.getString("description"),
                    resultSet.getString("status"),
                    resultSet.getString("created_at")
            ));
        }
        return requests;
    }
}
