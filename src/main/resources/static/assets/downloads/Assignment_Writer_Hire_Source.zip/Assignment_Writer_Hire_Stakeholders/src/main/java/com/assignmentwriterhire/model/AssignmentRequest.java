package com.assignmentwriterhire.model;

public class AssignmentRequest {

    private int id;
    private int userId;
    private String userName;
    private String title;
    private String subject;
    private String assignmentType;
    private String deadline;
    private int pages;
    private double budget;
    private String description;
    private String status;
    private String createdAt;

    public AssignmentRequest() {
    }

    public AssignmentRequest(
            int id,
            int userId,
            String userName,
            String title,
            String subject,
            String assignmentType,
            String deadline,
            int pages,
            double budget,
            String description,
            String status,
            String createdAt
    ) {
        this.id = id;
        this.userId = userId;
        this.userName = userName;
        this.title = title;
        this.subject = subject;
        this.assignmentType = assignmentType;
        this.deadline = deadline;
        this.pages = pages;
        this.budget = budget;
        this.description = description;
        this.status = status;
        this.createdAt = createdAt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getAssignmentType() {
        return assignmentType;
    }

    public void setAssignmentType(String assignmentType) {
        this.assignmentType = assignmentType;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public double getBudget() {
        return budget;
    }

    public void setBudget(double budget) {
        this.budget = budget;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "#" + id + " - " + title;
    }
}
