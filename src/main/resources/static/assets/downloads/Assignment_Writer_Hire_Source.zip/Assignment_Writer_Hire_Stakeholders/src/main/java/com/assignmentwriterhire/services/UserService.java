package com.assignmentwriterhire.services;

import com.assignmentwriterhire.interfaces.UserInterface;
import com.assignmentwriterhire.model.User;
import com.assignmentwriterhire.singleton.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UserService implements UserInterface {

    @Override
    public List<User> getAllUsers() throws Exception {
        List<User> users = new ArrayList<>();
        String sql = """
                SELECT id, full_name, username, password, role, status
                FROM users
                ORDER BY role, full_name
                """;

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                users.add(new User(
                        resultSet.getInt("id"),
                        resultSet.getString("full_name"),
                        resultSet.getString("username"),
                        resultSet.getString("password"),
                        resultSet.getString("role"),
                        resultSet.getString("status")
                ));
            }
        }
        return users;
    }

    @Override
    public void updateStatus(int userId, String status) throws Exception {
        String sql = "UPDATE users SET status = ? "
                + "WHERE id = ? AND role <> 'Admin'";

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, status);
            statement.setInt(2, userId);
            statement.executeUpdate();
        }
    }

    @Override
    public int countUsers() throws Exception {
        String sql = "SELECT COUNT(*) FROM users WHERE role = 'User'";

        try (Connection connection = DatabaseConnection
                .getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            return resultSet.next() ? resultSet.getInt(1) : 0;
        }
    }
}
