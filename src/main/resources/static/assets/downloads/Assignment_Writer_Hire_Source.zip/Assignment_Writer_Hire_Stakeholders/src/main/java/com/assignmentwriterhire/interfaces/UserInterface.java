package com.assignmentwriterhire.interfaces;

import com.assignmentwriterhire.model.User;

import java.util.List;

public interface UserInterface {

    List<User> getAllUsers() throws Exception;

    void updateStatus(int userId, String status) throws Exception;

    int countUsers() throws Exception;
}
