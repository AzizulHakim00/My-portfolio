package com.assignmentwriterhire.interfaces;

import com.assignmentwriterhire.model.Writer;

import java.util.List;

public interface WriterInterface {

    List<Writer> getAllWriters() throws Exception;

    List<Writer> getAvailableWriters() throws Exception;

    void addWriter(Writer writer) throws Exception;

    void updateWriter(Writer writer) throws Exception;

    void deleteWriter(int writerId) throws Exception;

    int countAvailableWriters() throws Exception;
}
