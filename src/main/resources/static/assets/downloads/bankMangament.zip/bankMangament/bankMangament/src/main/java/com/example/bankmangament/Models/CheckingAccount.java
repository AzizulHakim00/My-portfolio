package com.example.bankmangament.Models;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class CheckingAccount extends Account {

    // the number of transactions a client allowed to do per day

    private final IntegerProperty TransactionLimit;

    public CheckingAccount(String owner, String accountNumber,double balance ,int tLimit) {
        super(owner , accountNumber , balance);
        this.TransactionLimit = new SimpleIntegerProperty(this , " Transaction Limit ", tLimit);

    }
    public IntegerProperty transactionLimitProperty() {
        return this.TransactionLimit;
    }

    @Override
    public String toString(){
        return accountNumberProperty().get();
    }
}
