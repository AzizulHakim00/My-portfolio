package com.example.bankmangament.Controllers.Admin;

import com.example.bankmangament.Models.Client;
import com.example.bankmangament.Models.Model;
import com.example.bankmangament.Views.ClientCellFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class DepositController implements Initializable {
    public TextField payeeAdress_fid;
    public ListView<Client> result_listview;
    public Button search_btn;
    public TextField amount_fid;
    public Button deposit_btn;

    private Client client;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        search_btn.setOnAction(event -> onClientSearch());
        deposit_btn.setOnAction(event -> onDeposit());
    }

    private void onClientSearch() {

        ObservableList<Client> searchResults = Model.getInstance().searchClient(payeeAdress_fid.getText());
        result_listview.setItems(searchResults);
        result_listview.setCellFactory(c -> new ClientCellFactory());
        client = searchResults.get(0);

    }

    private void onDeposit() {

        double amount = Double.parseDouble(amount_fid.getText());
        double newBalance = amount + client.savingsAccountProperty().get().balanceProperty().get();

        if(amount_fid.getText() != null){
            Model.getInstance().getDataBaseDriver().depositSavings(client.payeeAddressProperty().get(), newBalance);
        }
        emptyFields();
    }

    private void emptyFields() {
        payeeAdress_fid.setText("");
        amount_fid.setText("");

    }
}
