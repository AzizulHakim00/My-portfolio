module com.example.bankmangament {
    requires javafx.controls;
    requires javafx.fxml;
    requires de.jensd.fx.glyphs.fontawesome;
    requires java.sql;
    requires org.xerial.sqlitejdbc;
    requires java.desktop;


    opens com.example.bankmangament to javafx.fxml;
    exports com.example.bankmangament;
    exports com.example.bankmangament.Controllers;
    exports com.example.bankmangament.Models;
    exports com.example.bankmangament.Views;
    exports com.example.bankmangament.Controllers.Client;
    exports com.example.bankmangament.Controllers.Admin;
}