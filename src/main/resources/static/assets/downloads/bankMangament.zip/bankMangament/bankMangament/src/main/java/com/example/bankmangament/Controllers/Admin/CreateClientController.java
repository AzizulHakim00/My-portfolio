package com.example.bankmangament.Controllers.Admin;

import com.example.bankmangament.Models.Model;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.net.URL;
import java.time.LocalDate;
import java.util.Random;
import java.util.ResourceBundle;

public class  CreateClientController implements Initializable {
    public TextField fName_fid;
    public TextField LName_fid;
    public TextField passsword_fid;
    public CheckBox pAddress_box;
    public Label pAddress_lbl;
    public CheckBox ch_acc_box;
    public TextField ch_amount_fid;
    public CheckBox sv_acc_box;
    public Button create_client_btn;
    public TextField sv_amount_fid;
    public Label error_lbl;



    private String payeeAddress;

    private boolean createCheckingAccount  = false;
    private boolean createSavingsAccount  = false;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        create_client_btn.setOnAction(event -> createClient());
        pAddress_box.selectedProperty().addListener((observableValue, oldValue, newValue) -> {
            if(newValue){
                payeeAddress = createPayeeAddress();
                onCreatePayeeAddress();
            }
        });
        ch_acc_box.selectedProperty().addListener((observableValue, oldValue, newValue) -> {
            if(newValue){
                createCheckingAccount = true;
            }
        });
        sv_acc_box.selectedProperty().addListener((observableValue, oldValue, newValue) -> {
            if(newValue){
                createSavingsAccount = true;
            }
        });
    }


    private void createClient(){

        // create Checking acoubnt
        if(createCheckingAccount){
            createAccount("Checking");
        }
        // create saving account
        if(createSavingsAccount){
            createAccount("Savings");
        }
        // create Client
        String fName = fName_fid.getText();
        String lName = LName_fid.getText();
        String password = passsword_fid.getText();
        Model.getInstance().getDataBaseDriver().createClient(fName , lName , payeeAddress , password , LocalDate.now());

        error_lbl.setStyle("-fx-text-fill: blue ; -fx-font-size: 1.3em; -fx-font-weight: bold;");
        error_lbl.setText("Client created Successfully");

       emptyFields();

    }


    private void createAccount(String accountType){

        double balance = Double.parseDouble(ch_amount_fid.getText());

        // generate Account Number
        String firstSection = "3201";
        String lastSection = Integer.toString( (new Random()).nextInt(9999) + 1000);
        String accountNumber = firstSection + " "+ lastSection;

        // create the checking and savings  account
        if(accountType.equals("Checking")){
            Model.getInstance().getDataBaseDriver().createCheckingAccount(payeeAddress , accountNumber , 10 , balance);
        }
        else{
            Model.getInstance().getDataBaseDriver().createSavingsAccount(payeeAddress , accountNumber , 2000 , balance);
        }

    }

    private void onCreatePayeeAddress(){
        if(fName_fid.getText() != null && fName_fid.getText() != null){
            pAddress_lbl.setText(payeeAddress);
        }
    }

    private String createPayeeAddress(){
        int id = Model.getInstance().getDataBaseDriver().getLastClientID() + 1 ;
        char fChar = Character.toLowerCase(fName_fid.getText().charAt(0));
        return "@" + fChar + LName_fid.getText() + id;
    }

    private void emptyFields(){
        fName_fid.setText("");
        LName_fid.setText("");
        passsword_fid.setText("");

        pAddress_box.setSelected(false);
        pAddress_lbl.setText("");

        ch_acc_box.setSelected(false);
        ch_amount_fid.setText("");

        sv_acc_box.setSelected(false);
        sv_amount_fid.setText("");

    }
}
