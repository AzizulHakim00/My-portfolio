package com.example.bankmangament.Controllers.Client;

import com.example.bankmangament.Models.Client;
import com.example.bankmangament.Models.Model;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.BorderPane;

import java.net.URL;
import java.util.ResourceBundle;

public class ClientController implements Initializable {
    @FXML
    public BorderPane client_parent;




    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Model.getInstance().getViewfactory().getClientSelectMenuItem().addListener((observableValue, oldValue, newValue) -> {
            switch (newValue) {
                case TRANSACTION -> client_parent.setCenter(Model.getInstance().getViewfactory().getTransaction_view());
                case ACCOUNTS -> client_parent.setCenter(Model.getInstance().getViewfactory().getAccountView());
                default -> client_parent.setCenter(Model.getInstance().getViewfactory().getDashboardView());
            }

        });
    }
}
