package com.example.bankmangament.Controllers;

import com.example.bankmangament.Models.Model;

import com.example.bankmangament.Views.AccountType;
import javafx.collections.FXCollections;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    public ChoiceBox<AccountType> account_selector;
    public Label payee_adress;
    public TextField payee_address_field;
    public TextField password_field;
    public Button login_btn;
    public Label error_lbl;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        account_selector.setItems(FXCollections.observableArrayList(AccountType.CLIENT , AccountType.ADMIN));
        account_selector.setValue(Model.getInstance().getViewfactory().getLoginAccountType());
        account_selector.valueProperty().addListener(observable -> setAcc_selector());
        login_btn.setOnAction(event -> onLogin());
    }
    private void onLogin(){
        Stage stage = (Stage) error_lbl.getScene().getWindow();


        if(Model.getInstance().getViewfactory().getLoginAccountType() == AccountType.CLIENT){
            // evaluate client login credentials
            Model.getInstance().evaluateClientCred(payee_address_field.getText(), password_field.getText());

            if(Model.getInstance().getClientLoginSuccessFlag()){

                Model.getInstance().getViewfactory().showClientWindow();

                Model.getInstance().getViewfactory().closeStage(stage);

                // close the login stage
            }
            else{
                payee_address_field.setText("");
                password_field.setText("");
                error_lbl.setText("No such Login Credentials");
            }
        }
        else{
            // Evaluate adin Login Credentials
            Model.getInstance().evaluateAdminCred(payee_address_field.getText(), password_field.getText());
            if(Model.getInstance().getAdminLoginSuccessFlag()){

                Model.getInstance().getViewfactory().showAdminwindow();

                // close the login stage
                Model.getInstance().getViewfactory().closeStage(stage);


            }
            else{
                payee_address_field.setText("");
                password_field.setText("");
                error_lbl.setText("No such Login Credentials");
            }
        }

    }

    private void setAcc_selector(){
        Model.getInstance().getViewfactory().setLoginAccountType(account_selector.getValue());

        // change payee adresss lebel ;
        if( account_selector.getValue() == AccountType.ADMIN){
            payee_adress.setText("Username");
        }
        else{
            payee_adress.setText("Payee Address");
        }
    }
}
