package com.example.bankmangament.Controllers.Admin;

import com.example.bankmangament.Models.Model;
import com.example.bankmangament.Views.AdminMenuOptions;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class AdminMenuController implements Initializable {
    public Button create_client_btn;
    public Button client_btn;
    public Button deposit_btn;
    public Button logout_btn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
       addListeners();
    }
    private void addListeners(){
        create_client_btn.setOnAction(event -> onCreateClient());
        client_btn.setOnAction(event -> onClients());
        deposit_btn.setOnAction(event -> onDeposit());
        logout_btn.setOnAction(event -> onLogout());
    }
    private void onCreateClient(){
        Model.getInstance().getViewfactory().getAdminSelectMenuItem().set(AdminMenuOptions.CREATECLIENT);
    }
    private void onClients(){
        Model.getInstance().getViewfactory().getAdminSelectMenuItem().set(AdminMenuOptions.CLIENTS);
    }
    private void onDeposit(){
        Model.getInstance().getViewfactory().getAdminSelectMenuItem().set(AdminMenuOptions.DEPOSITS);
    }
    private void onLogout(){
        // get Stage

        Stage stage = (Stage) client_btn.getScene().getWindow();

        // close the admin window

        Model.getInstance().getViewfactory().closeStage(stage);

        // show login window

        Model.getInstance().getViewfactory().showLolginWindow();

        // set  admim success flag to false

        Model.getInstance().setAdminLoginSuccessFlag(false);
    }

}
