package com.example.bankmangament.Controllers.Client;

import com.example.bankmangament.Models.Model;
import com.example.bankmangament.Views.ClientMenuOptions;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class ClientMenuController implements Initializable {
    public Button dassboard_btn;
    public Button transaction_btn;
    public Button account_btn;
    public Button profile_btn;
    public Button logout_btn;
    public Button report_btn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
            addListeners();
    }
    private void addListeners(){
        dassboard_btn.setOnAction(event -> onDashboard());
        transaction_btn.setOnAction(actionEvent -> onTransaction());
        account_btn.setOnAction(actionEvent -> onAccount());
        logout_btn.setOnAction(actionEvent -> onLogout());
    }
    private void onDashboard(){
        Model.getInstance().getViewfactory().getClientSelectMenuItem().set(ClientMenuOptions.DASHBOARD);
    }
    private void onTransaction(){
        Model.getInstance().getViewfactory().getClientSelectMenuItem().set(ClientMenuOptions.TRANSACTION);
    }
    private void onAccount(){
        Model.getInstance().getViewfactory().getClientSelectMenuItem().set(ClientMenuOptions.ACCOUNTS);
    }
    private void onLogout(){
        // get Stage

        Stage stage = (Stage) dassboard_btn.getScene().getWindow();

        // close the Client window

        Model.getInstance().getViewfactory().closeStage(stage);

        // show login window

        Model.getInstance().getViewfactory().showLolginWindow();

        // set clint login success flag to false

        Model.getInstance().setClientLoginSuccessFlag(false);
    }

}
