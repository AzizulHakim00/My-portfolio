package com.example.bankmangament.Views;

import com.example.bankmangament.Controllers.Admin.AdminController;
import com.example.bankmangament.Controllers.Client.ClientController;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Viewfactory {




    // for login type
    private AccountType loginAccountType;

    // client views

    private final ObjectProperty<ClientMenuOptions> clientSelectMenuItem;

    private AnchorPane dashboardView;
    private AnchorPane transaction_view;
    private AnchorPane account_view;


    // admin view

    private final  ObjectProperty<AdminMenuOptions>  adminSelectMenuItem;

    private AnchorPane clients_view ;
    private AnchorPane create_client_view;
    private AnchorPane deposit_view;

    public Viewfactory() {


        this.loginAccountType = AccountType.CLIENT ;
        this.adminSelectMenuItem = new SimpleObjectProperty<>();

        this.clientSelectMenuItem = new SimpleObjectProperty<>();
    }



    public AccountType getLoginAccountType() {
        return loginAccountType;
    }

    public void setLoginAccountType(AccountType loginAccountType) {

        this.loginAccountType = loginAccountType;
    }

    public ObjectProperty<ClientMenuOptions> getClientSelectMenuItem() {

        return clientSelectMenuItem;
    }


    public AnchorPane getDashboardView() {
        if(dashboardView == null) {
            try{
                dashboardView = new FXMLLoader(getClass().getResource("/com/example/bankmangament/Client/Dashboard.fxml")).load();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return dashboardView;
    }

    public AnchorPane getTransaction_view()  {
        if(transaction_view == null) {
            try{
                transaction_view = new FXMLLoader(getClass().getResource("/com/example/bankmangament/Client/Transaction.fxml")).load();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        return transaction_view;

    }

    public AnchorPane getAccountView() {
        if(account_view == null) {
            try{
                account_view = new FXMLLoader(getClass().getResource("/com/example/bankmangament/Client/Accounts.fxml")).load();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        return account_view;
    }


    public void showClientWindow() {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/bankmangament/Client/Client.fxml"));
        ClientController clientController = new ClientController();
        loader.setController(clientController);
        createStage(loader);
    }

    // admin section

    public ObjectProperty<AdminMenuOptions> getAdminSelectMenuItem() {

        return adminSelectMenuItem;
    }


    public AnchorPane getCreate_client_view() {
        if(create_client_view == null) {
            try{
                create_client_view = new FXMLLoader(getClass().getResource("/com/example/bankmangament/Admin/CreateClient.fxml")).load();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        return create_client_view;
    }

    public AnchorPane getClients_view() {
        if(clients_view == null) {
            try{
                    clients_view = new FXMLLoader(getClass().getResource("/com/example/bankmangament/Admin/Clients.fxml")).load();
                }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        return clients_view;
    }

    public AnchorPane getDeposit_view() {
        if(deposit_view == null) {
            try{
                deposit_view = new FXMLLoader(getClass().getResource("/com/example/bankmangament/Admin/Deposit.fxml")).load();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        return deposit_view;
    }

    public void showAdminwindow(){
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/bankmangament/Admin/Admin.fxml"));
        AdminController adminController = new AdminController();
        fxmlLoader.setController(adminController);
        createStage(fxmlLoader);
    }

    // login section

    public void showLolginWindow() {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/bankmangament/Login.fxml"));
        createStage(loader);

    }

    public void showMessageWindow(String pAddress ,String messageText) {
        StackPane pane = new StackPane();
        HBox hBox = new HBox(5);
        hBox.setAlignment(Pos.CENTER);
        Label sender = new Label(pAddress);
        Label messsage = new Label(messageText);
        hBox.getChildren().addAll(sender,messsage);
        pane.getChildren().add(hBox);
        Scene scene = new Scene(pane, 300, 100);
        Stage stage = new Stage();
        stage.getIcons().add(new Image(String.valueOf(getClass().getResource("/Images/download.png"))));
        stage.setResizable(false);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Message");
        stage.setScene(scene);
        stage.show();

    }


    private void createStage(FXMLLoader loader , double... dimensions ) {
        Scene scene = null;
        try{
            scene = new Scene(loader.load());
        }
        catch (Exception e){
            e.printStackTrace();
        }
        Stage stage = new Stage();
        stage.getIcons().add(new Image(String.valueOf(getClass().getResource("/Images/download.png"))));
        stage.setResizable(false);
        stage.setScene(scene);
        stage.setTitle("Maze Bank");
        stage.show();
    }
    public void closeStage(Stage stage) {
        stage.close();

    }
}
