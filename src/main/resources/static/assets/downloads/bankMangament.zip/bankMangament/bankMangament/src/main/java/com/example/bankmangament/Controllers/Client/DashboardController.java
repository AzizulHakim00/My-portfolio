package com.example.bankmangament.Controllers.Client;

import com.example.bankmangament.Models.Model;
import com.example.bankmangament.Models.Transaction;
import com.example.bankmangament.Views.TransactionCellFactory;
import javafx.beans.binding.Bindings;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.text.Text;

import java.net.URL;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {
    public Text user_name;
    public Label login_date;
    public Label checking_balance;
    public Label checking_acc_num;
    public Label savings_bal;
    public Label savings_acc_num;
    public Label income_lbl;
    public Label expense_lbl;
    public ListView transaction_list_view;
    public TextField payee_flb;
    public TextField amount_flb;
    public TextArea massage_flb;
    public Button send_money_btn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
            bindData();
            iniLatestTransactionsList();
            transaction_list_view.setItems(Model.getInstance().getLatestTransactions());
            transaction_list_view.setCellFactory( c -> new TransactionCellFactory());
            send_money_btn.setOnAction(event -> onSendMoney());
            accountSummary();

    }

    public void bindData(){

        user_name.textProperty().bind(Bindings.concat( "HI, ").concat(Model.getInstance().getClient().firstNameProperty()));
        login_date.setText("Today," + LocalDate.now());
        checking_balance.textProperty().bind(Model.getInstance().getClient().checkingAccountProperty().get().balanceProperty().asString());

        checking_acc_num.textProperty().bind((Model.getInstance().getClient().checkingAccountProperty().get().accountNumberProperty()));

        savings_bal.textProperty().bind(Model.getInstance().getClient().savingsAccountProperty().get().balanceProperty().asString());

        savings_acc_num.textProperty().bind(Model.getInstance().getClient().savingsAccountProperty().get().accountNumberProperty());

    }
    private void iniLatestTransactionsList(){
            if(Model.getInstance().getLatestTransactions().isEmpty()){
                Model.getInstance().setLatestTransactions();
            }
    }

    private void onSendMoney(){
        String receiver = payee_flb.getText();
        double amount = Double.parseDouble(amount_flb.getText());
        String message = massage_flb.getText();
        String sender = Model.getInstance().getClient().payeeAddressProperty().get();
        ResultSet resultSet = Model.getInstance().getDataBaseDriver().searchClient(receiver);
        try {
            if(resultSet.isBeforeFirst()){
                Model.getInstance().getDataBaseDriver().updateBalance(receiver , amount , "Add");
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }

        // subtract from sender''s savings account
        Model.getInstance().getDataBaseDriver().updateBalance(receiver , amount , "Sub");

        // update the savings account balance in the client object

        Model.getInstance().getClient().savingsAccountProperty().get().setBalance(Model.getInstance().getDataBaseDriver().getSavingsAccountBalance(sender));

        // record new transaction

        Model.getInstance().getDataBaseDriver().newTransaction(sender , receiver , amount , message);

        // clear the fields

        payee_flb.setText("");
        amount_flb.setText("");
        massage_flb.setText("");

    }

    // method calculates all expenses and income

    private  void accountSummary(){
        double income = 0 ;
        double expense = 0 ;
        if(Model.getInstance().getAllTransactions().isEmpty()){

            Model.getInstance().setAllTransactions();

        }
        for(Transaction transaction : Model.getInstance().getAllTransactions()){

            if(transaction.senderProperty().get().equals(Model.getInstance().getClient().payeeAddressProperty().get())){

                expense += transaction.amountProperty().get();

            }
            else{
                income += transaction.amountProperty().get();
            }
        }
        income_lbl.setText(" + $" + income);
        expense_lbl.setText("- $" + expense);
    }

}
