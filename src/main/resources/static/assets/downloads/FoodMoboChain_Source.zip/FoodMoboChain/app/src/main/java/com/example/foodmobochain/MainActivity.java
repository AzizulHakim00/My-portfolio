package com.example.foodmobochain;

import android.os.Bundle;
import android.util.Log;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.FirebaseApp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize Firebase
        FirebaseApp.initializeApp(this);

        // Enabling edge-to-edge UI (optional, try commenting this out if you suspect issues)
        // EdgeToEdge.enable(this);

        setContentView(R.layout.activity_main);

        // Handling window insets (optional)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Write a message to the Firebase Realtime Database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("anything");

        myRef.setValue("hello anything").addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                // Success
                Log.d("Firebase", "Data written successfully");
            } else {
                // Failure
                Log.e("Firebase", "Failed to write data", task.getException());
            }
        });
    }
}
